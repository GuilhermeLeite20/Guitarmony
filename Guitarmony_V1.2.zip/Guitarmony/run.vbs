Option Explicit
Dim shell, fs, folder, executable, runtime, jar
Set shell = CreateObject("WScript.Shell")
Set fs = CreateObject("Scripting.FileSystemObject")
folder = fs.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = folder
executable = fs.BuildPath(folder, "Guitarmony.exe")
If fs.FileExists(executable) Then
    shell.Run Chr(34) & executable & Chr(34), 1, False
Else
    runtime = fs.BuildPath(folder, "dist\runtime\bin\javaw.exe")
    jar = fs.BuildPath(folder, "dist\Guitarmony.jar")
    If fs.FileExists(runtime) And fs.FileExists(jar) Then
        shell.Run Chr(34) & runtime & Chr(34) & " -Dfile.encoding=UTF-8 -jar " & Chr(34) & jar & Chr(34), 1, False
    Else
        MsgBox "Extraia o ZIP completo e abra Guitarmony.exe.", 48, "Guitarmony"
    End If
End If
