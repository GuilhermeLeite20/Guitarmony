@echo off
setlocal DisableDelayedExpansion
cd /d "%~dp0"
if exist Guitarmony.exe (
  start "" "%~dp0Guitarmony.exe"
  exit /b 0
)
wscript.exe "%~dp0run.vbs"
exit /b %errorlevel%
