# Guitarmony 1.2

Estudo visual de guitarra: modos, pentatônicas, pentablues, arpejos, escalas,
acordes, campos harmônicos e ciclos das quintas e quartas. Seis cordas, 24 casas e afinações
personalizadas. Funciona sem conexão e não precisa de cadastro.

## Abrir no Windows

1. **Extraia o ZIP inteiro** para uma pasta do computador.
2. Abra **Guitarmony.exe** com dois cliques.

O aplicativo abre sua janela diretamente, sem terminal. O Java portátil já está
incluído: **não é necessário instalar Java**. Mantenha a pasta `dist` ao lado do
executável. Pacote para Windows 10/11 de 64 bits (x64).

`run.vbs` e `run.bat` são atalhos alternativos para o mesmo executável.
Os scripts `build` e `test` são apenas para desenvolvimento.

## Área de estudo

- Selecione uma matéria nas abas superiores, a **tônica**, a **fórmula** e a
  **visualização**. Toda alteração atualiza o braço imediatamente.
- **Braço inteiro** localiza todas as ocorrências; **Um desenho** mostra uma
  posição; **Sequência** conecta desenhos. As tônicas ficam sempre em verde.
- **Sobrepor seleção** fixa o estudo para comparar com outro. **Limpar**, ou
  `Ctrl+L`, remove marcações e progressões.
- Passe o mouse e clique em notas para inspecionar corda, casa, nota e intervalo.
- Leia os quatro blocos **Entenda o que está vendo** para conhecer a estrutura,
  interpretar o braço e praticar cada matéria.

## Leitura ampliada na versão 1.2

O braço tem 450 px de altura e as notas usam fonte de 16 px, com marcadores
maiores e tônicas verdes. O modo realista mantém madeira, trastes e marcações,
sem cordas horizontais por trás das notas. Abaixo de 1450 px de largura útil,
o braço oferece rolagem horizontal em vez de diminuir as notas. Todos os trastes
continuam disponíveis, e passar o mouse ou clicar identifica cada posição.
Os controles e textos de apoio também usam fontes maiores.

Nas abas **Pentatônicas** e **Pentablues**, um cartão adicional sugere acordes
para acompanhar, progressões e notas do acorde para concluir frases. As sugestões
acompanham a tônica e a fórmula. São possibilidades musicais, não uma obrigação
de finalizar toda frase no mesmo acorde; blue notes podem funcionar como passagem.

## Configurações

A engrenagem abre uma janela central com:

- Afinação padrão e alternativas, transposição **−/+ 1 tom** (dois semitons) e
  ajuste individual de cada corda.
- Preferência por bemóis e alternância entre braço simplificado e **Escala
  realista**, com madeira, pestana, trastes e marcações.
- **Corda de partida**: comece um desenho na 6ª Mi, 5ª Lá, 4ª Ré, 3ª Sol,
  2ª Si ou 1ª Mi. As cordas mais graves ficam livres nesse desenho. Essa
  preferência vale para Um desenho e Sequência; Braço inteiro permanece completo.

## Acordes, campos e armaduras

**Acordes** reúne seleção de graus, tríades/tétrades, mapa de notas, formas
**Voicing tocável** e progressões. O mapa mostra locais alternativos das notas;
não é um acorde para tocar todas as bolinhas simultaneamente. Voicings mostram
uma posição por corda e X para cordas abafadas. As posições são ordenadas pela facilidade de execução: abertura da mão, dedos,
pestanas e cordas soltas. As inversões podem facilitar a posição sem retirar
nenhuma nota do acorde. O diagrama ao lado mostra cordas abafadas/soltas, pestanas e dedos 1–4.
Confira sempre o conforto da sua mão; em afinações
extremas pode não haver uma posição que satisfaça todos os critérios.

**Campos** apresenta uma folha completa, com notas maiores, 17 grafias usuais
que cobrem as 12 tonalidades e seus sete graus, sem uma janela pequena dentro
da tabela. Escolha maior, menor natural, menor harmônica ou maior harmônica;
alterne tríades e tétrades. Role a página se a tela for menor. Clique numa cifra
ou num cartão de grau para visualizar aquele acorde no braço. As setas do teclado
selecionam uma célula; Enter aplica o tom e o acorde.

**Armadura de Clave** permite alternar entre **Ciclo das quintas** e **Ciclo das
quartas**. O desenho, a ordem dos botões e a explicação acompanham a escolha.
Clique num tom para estudar sua escala e ver dominante, subdominante e relativa
menor. Nesta aba, os controles de fórmula, visualização e sobreposição ficam
ocultos; nas outras matérias eles continuam disponíveis.

A interface usa nomes enarmônicos familiares: por exemplo, F no lugar de E#.
A altura sonora e o grau continuam corretos. A lógica interna preserva a grafia
diatônica para análise e testes; a tela não exibe acidentes pouco usuais ou duplos.

## Desenvolver no IntelliJ ou em outro sistema

Abra `pom.xml` com um **JDK completo 17 ou superior**. Não use apenas um JRE para
compilar. A aplicação é Java/Swing e não possui dependências externas em runtime.

```sh
# Linux/macOS (JDK 17+ no PATH)
bash build.sh
bash test.sh
bash run.sh
```

```bat
rem Windows (JDK 17+ no PATH)
build.bat
test.bat
```

O build atualiza `dist/Guitarmony.jar` incluindo imagens e ícones. Para Linux e
macOS, execute `java -jar dist/Guitarmony.jar` numa sessão gráfica com Java 17+.
O executável e o runtime incluídos são específicos de Windows x64.

Com Maven instalado, `mvn test` executa as mesmas suítes headless e `mvn package`
gera o JAR. Os scripts diretos não precisam do Maven nem de downloads.

As suítes verificam teoria em todas as tonalidades, equivalência enarmônica,
campos maiores/menores, voicings, posições e sequências por corda, cores das
tônicas, interação real dos controles Swing, tabela harmônica e navegação.
Para validar janelas modais e capturas numa sessão gráfica, execute também
`com.guitarmony.DesktopIntegrationChecks` com `build/classes` e
`build/test-classes` no classpath (separador `;` no Windows, `:` no Linux/macOS).

O launcher Windows é nativo e usa `javaw.exe` sem shell. Código, procedimento de
compilação e procedência do Java portátil estão em `windows/`. O funcionamento
Swing foi validado no Linux com display virtual; o executável Windows foi
inspecionado como PE x64 gráfico com ícone. Não foi executado em Windows nesta
máquina de desenvolvimento.
