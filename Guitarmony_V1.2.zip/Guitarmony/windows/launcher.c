#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <wchar.h>

static int fail(const wchar_t *message) {
    MessageBoxW(NULL, message, L"Guitarmony", MB_OK | MB_ICONERROR);
    return 1;
}

/* Resolve DWM dynamically so unsupported Windows versions retain native chrome. */
typedef HRESULT (WINAPI *SetWindowAttributeFn)(HWND, DWORD, LPCVOID, DWORD);
typedef struct {
    DWORD process_id;
    SetWindowAttributeFn set_attribute;
    BOOL found;
} TitleBarContext;

static BOOL CALLBACK style_title_bar(HWND window, LPARAM value) {
    TitleBarContext *context = (TitleBarContext *)value;
    DWORD process_id = 0;
    wchar_t class_name[64], title[128];
    GetWindowThreadProcessId(window, &process_id);
    if (process_id != context->process_id || !IsWindowVisible(window)) return TRUE;
    if (!GetClassNameW(window, class_name, 64) || wcscmp(class_name, L"SunAwtFrame") != 0) return TRUE;
    if (!GetWindowTextW(window, title, 128) || !wcsstr(title, L"Guitarmony")) return TRUE;
    BOOL enabled = TRUE;
    HRESULT result = context->set_attribute(window, 20, &enabled, sizeof(enabled));
    if (FAILED(result)) context->set_attribute(window, 19, &enabled, sizeof(enabled));
    COLORREF caption = RGB(43, 43, 43);
    context->set_attribute(window, 35, &caption, sizeof(caption));
    SetWindowPos(window, NULL, 0, 0, 0, 0,
                 SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED);
    context->found = TRUE;
    return FALSE;
}

static void request_dark_title_bar(const PROCESS_INFORMATION *process) {
    HMODULE dwm = LoadLibraryExW(L"dwmapi.dll", NULL, LOAD_LIBRARY_SEARCH_SYSTEM32);
    if (!dwm) return;
    /* FARPROC is intentionally converted only after checking the exported symbol. */
    union { FARPROC symbol; SetWindowAttributeFn function; } resolved;
    resolved.symbol = GetProcAddress(dwm, "DwmSetWindowAttribute");
    if (resolved.symbol) {
        TitleBarContext context = {process->dwProcessId, resolved.function, FALSE};
        for (int attempt = 0; attempt < 40 && !context.found; ++attempt) {
            if (WaitForSingleObject(process->hProcess, 0) != WAIT_TIMEOUT) break;
            EnumWindows(style_title_bar, (LPARAM)&context);
            if (!context.found) Sleep(250);
        }
    }
    FreeLibrary(dwm);
}

/* GUI subsystem entry point: no shell, no console, no command interpreter. */
int WINAPI wWinMain(HINSTANCE instance, HINSTANCE previous, PWSTR arguments, int show) {
    (void)instance; (void)previous; (void)arguments; (void)show;
    wchar_t directory[32768], java[32768], jar[32768], command[65536];
    DWORD length = GetModuleFileNameW(NULL, directory, 32768);
    if (!length || length >= 32768) return fail(L"Não foi possível localizar a pasta do aplicativo.");
    wchar_t *separator = wcsrchr(directory, L'\\');
    if (!separator) return fail(L"Extraia o ZIP completo antes de abrir o Guitarmony.");
    *separator = L'\0';
    if (wcslen(directory) > 32000) return fail(L"Extraia o aplicativo em uma pasta com caminho mais curto.");
    swprintf(java, 32768, L"%ls\\dist\\runtime\\bin\\javaw.exe", directory);
    swprintf(jar, 32768, L"%ls\\dist\\Guitarmony.jar", directory);
    if (GetFileAttributesW(java) == INVALID_FILE_ATTRIBUTES)
        return fail(L"O Java portátil do aplicativo não foi encontrado.\n\nExtraia TODO o arquivo ZIP e mantenha a pasta dist junto de Guitarmony.exe.");
    if (GetFileAttributesW(jar) == INVALID_FILE_ATTRIBUTES)
        return fail(L"O arquivo dist\\Guitarmony.jar não foi encontrado.\n\nExtraia TODO o ZIP antes de executar o programa.");
    swprintf(command, 65536, L"\"%ls\" -Dfile.encoding=UTF-8 -jar \"%ls\"", java, jar);
    STARTUPINFOW startup = {0};
    PROCESS_INFORMATION process = {0};
    startup.cb = sizeof(startup);
    if (!CreateProcessW(java, command, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, directory, &startup, &process))
        return fail(L"Não foi possível abrir o Guitarmony.\n\nUse o Windows 10/11 de 64 bits e extraia novamente o ZIP completo. Nenhuma instalação de Java é necessária.");
    CloseHandle(process.hThread);
    request_dark_title_bar(&process);
    WaitForSingleObject(process.hProcess, INFINITE);
    DWORD result = 0;
    GetExitCodeProcess(process.hProcess, &result);
    CloseHandle(process.hProcess);
    if (result != 0) return fail(L"O aplicativo encerrou com um erro.\n\nExtraia novamente o pacote completo. Para diagnóstico de desenvolvimento, execute java -jar dist\\Guitarmony.jar.");
    return 0;
}
