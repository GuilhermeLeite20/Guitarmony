#!/usr/bin/env python3
"""Fetch the exact redistributable Temurin runtime, retaining TLS and SHA-256 verification."""
import hashlib
import pathlib
import tempfile
import urllib.request
import zipfile

VERSION = "21.0.13_9"
SHA256 = "2332c0b4cff6bed722da3567c91d5e47568bcba863fa4945d0a8d6fc76158628"
URL = (
    "https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.13%2B9/"
    f"OpenJDK21U-jre_x64_windows_hotspot_{VERSION}.zip"
)
ROOT = pathlib.Path(__file__).resolve().parents[1]
TARGET = ROOT / "dist" / "runtime"

def main():
    if TARGET.exists():
        raise SystemExit("dist/runtime já existe. Preserve-a ou remova-a explicitamente antes de baixar novamente.")
    with tempfile.TemporaryDirectory(prefix="guitarmony-runtime-") as temporary:
        archive = pathlib.Path(temporary) / "runtime.zip"
        with urllib.request.urlopen(URL, timeout=120) as response, archive.open("wb") as output:
            while chunk := response.read(1024 * 1024):
                output.write(chunk)
        actual = hashlib.sha256(archive.read_bytes()).hexdigest()
        if actual != SHA256:
            raise SystemExit(f"Falha de integridade: SHA-256 recebido {actual}.")
        with zipfile.ZipFile(archive) as bundle:
            prefix = bundle.namelist()[0].split("/")[0]
            for entry in bundle.infolist():
                parts = pathlib.PurePosixPath(entry.filename).parts
                if not parts or parts[0] != prefix or ".." in parts or entry.filename.startswith("/"):
                    raise SystemExit("Caminho inválido no pacote oficial.")
            for entry in bundle.infolist():
                parts = pathlib.PurePosixPath(entry.filename).parts[1:]
                target = TARGET.joinpath(*parts)
                if entry.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                else:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(bundle.read(entry))
    print(f"Java portátil {VERSION} extraído em {TARGET}; SHA-256 verificado.")

if __name__ == "__main__":
    main()
