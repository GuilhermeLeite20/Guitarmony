package com.guitarmony;

import com.guitarmony.music.*;
import com.guitarmony.fretboard.*;
import com.guitarmony.ui.WorkspacePanel;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.util.List;

/** Regression checks for readable V1.2 tables, armatures, advice and retained preferences. */
public final class V12UiChecks {
    private static int checks;
    public static void main(String[] args)throws Exception {
        Throwable[] failure={null};SwingUtilities.invokeAndWait(()->{
            JFrame frame=null;
            try {
                GuitarmonyApp.installLookAndFeel();WorkspacePanel ui=new WorkspacePanel();
                if(args.length>0&&args[0].equals("--desktop")){
                    frame=new JFrame("Guitarmony V1.2");frame.setContentPane(ui);frame.setSize(1510,1050);frame.setLocation(20,10);frame.setVisible(true);frame.validate();
                }else{ui.setSize(1440,1000);layout(ui);}
                click(ui,"Aba Campos");layout(ui);
                JTable table=(JTable)find(ui,"Tabela de campos harmônicos");
                check(table.getRowCount()==17,"Table retains twelve pitches plus common written aliases");
                check(table.getFont().getSize()>=18&&table.getRowHeight()>=44,"Table typography is large");
                check(!(table.getParent() instanceof JViewport),"No nested table viewport hides rows");
                check(table.getPreferredSize().height>=table.getRowCount()*table.getRowHeight(),"Every table row has space in page");
                check(table.getParent().getPreferredSize().height>=table.getPreferredSize().height+40,"Header and all rows fit complete table");
                check(table.getParent().getX()<=16&&table.getParent().getWidth()>=table.getParent().getParent().getWidth()*.95,"Full table fills card instead of shifting right");
                check(table.getValueAt(0,0).equals("C")&&table.getValueAt(1,0).equals("G")&&table.getValueAt(2,0).equals("D"),"Table follows fifth order");
                Set<Integer> pitches=new HashSet<>();Set<String> spellings=new HashSet<>();
                for(int row=0;row<table.getRowCount();row++){String name=(String)table.getValueAt(row,0);pitches.add(Notes.pitch(name));spellings.add(name);}
                check(pitches.size()==12&&spellings.containsAll(Set.of("F#","Gb","C#","Db","Bb")),"All pitches and useful aliases included");
                JComboBox<Formula> formula=combo(ui,"Fórmula");formula.setSelectedItem(Catalog.byId("harmonic-minor"));
                table=(JTable)find(ui,"Tabela de campos harmônicos");int aRow=row(table,"A");check("E7".equals(table.getValueAt(aRow,5)),"A harmonic minor fifth degree is E7");
                table.setSize(1200,table.getPreferredSize().height);Rectangle target=table.getCellRect(aRow,5,true);
                MouseEvent event=new MouseEvent(table,MouseEvent.MOUSE_CLICKED,System.currentTimeMillis(),0,target.x+3,target.y+3,1,false);
                for(var listener:table.getMouseListeners())listener.mouseClicked(event);
                check(combo(ui,"Tônica").getSelectedItem().equals("A"),"Full table selection changes key");
                check(combo(ui,"Acorde do campo").getSelectedIndex()==4,"Full table selection changes degree");
                table=(JTable)find(ui,"Tabela de campos harmônicos");table.changeSelection(row(table,"D"),4,false,false);
                check("Aplicar seleção do campo".equals(table.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).get(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_ENTER,0))),"Enter key is bound to apply selected table cell");
                table.getActionMap().get("Aplicar seleção do campo").actionPerformed(new java.awt.event.ActionEvent(table,0,"test-enter"));
                check(combo(ui,"Tônica").getSelectedItem().equals("D")&&combo(ui,"Acorde do campo").getSelectedIndex()==3,"Enter applies the highlighted key and chord without requiring a mouse");
                combo(ui,"Tônica").setSelectedItem("A");combo(ui,"Acorde do campo").setSelectedIndex(4);
                layout(ui);captureFullPage(ui,"docs/v1.2-campos-completo.png");
                click(ui,"Aba Armadura de Clave");layout(ui);
                check(!find(ui,"Campo O que estudar").isVisible(),"Armature hides formula label and input");
                check(!find(ui,"Campo Visualização").isVisible(),"Armature hides visualization label and input");
                check(!find(ui,"Sobrepor seleção").isVisible(),"Armature hides overlay control");
                check(find(ui,"Tônica").isVisible(),"Armature keeps tonic selection");
                JComboBox<String> direction=combo(ui,"Sentido do ciclo");
                JPanel keyboard=(JPanel)find(ui,"Tons do ciclo em ordem");
                check(buttons(keyboard).subList(0,3).equals(List.of("C","G","D")),"Fifths keyboard runs C G D clockwise");
                check(find(ui,"Ciclo das quintas interativo")!=null,"Fifths wheel is accessible");
                captureFullPage(ui,"docs/v1.2-armadura-quintas.png");
                direction.setSelectedIndex(1);layout(ui);keyboard=(JPanel)find(ui,"Tons do ciclo em ordem");
                check(buttons(keyboard).subList(0,3).equals(List.of("C","F","Bb")),"Fourths reverse the physical key order");
                check(find(ui,"Ciclo das quartas interativo")!=null,"Fourths wheel is accessible");
                Object panel=find(ui,"Painel de armadura de clave");Method at=panel.getClass().getDeclaredMethod("keyForSlot",int.class);at.setAccessible(true);
                check("F".equals(at.invoke(panel,1)),"The clockwise drawn fourths node is F");
                clickText(keyboard,"Bb");check(combo(ui,"Tônica").getSelectedItem().equals("Bb"),"Fourths keys select the corresponding tonic");
                captureFullPage(ui,"docs/v1.2-armadura-quartas.png");
                combo(ui,"Tônica").setSelectedItem("C#");check(((JLabel)find(ui,"Acidentes da armadura")).getText().equals("7 sustenidos"),"C# major armature reports seven sharps");
                combo(ui,"Tônica").setSelectedItem("Gb");check(((JLabel)find(ui,"Acidentes da armadura")).getText().equals("6 bemóis"),"Gb major armature reports six flats");
                combo(ui,"Tônica").setSelectedItem("G#");check(((JLabel)find(ui,"Tom da armadura")).getText().equals("Ab maior (G#)")&&((JLabel)find(ui,"Acidentes da armadura")).getText().equals("4 bemóis"),"G# explicitly uses familiar Ab armature with four flats");
                combo(ui,"Tônica").setSelectedItem("D#");check(((JLabel)find(ui,"Tom da armadura")).getText().equals("Eb maior (D#)"),"D# major explicitly identifies its Eb equivalent");
                combo(ui,"Tônica").setSelectedItem("A#");check(((JLabel)find(ui,"Tom da armadura")).getText().equals("Bb maior (A#)"),"A# major explicitly identifies its Bb equivalent");
                JComboBox<String> starting=combo(ui,"Corda de partida");starting.setSelectedIndex(1);
                click(ui,"Aba Acordes");check(!find(ui,"Diagrama de acorde").isVisible(),"Map mode starts without a playable-grip diagram");
                click(ui,"Voicing tocável");layout(ui);JComponent diagram=find(ui,"Diagrama de acorde");
                check(diagram.isVisible(),"Playable grip toggle reveals the chord diagram");
                check(diagram.getWidth()>=250&&diagram.getHeight()>=330,"Integrated diagram remains legible beside chord controls");
                check(combo(ui,"Forma do acorde").getWidth()>=440,"Integrated diagram does not squeeze the form picker");
                captureFullPage(ui,"docs/v1.2-acordes-com-forma.png");click(ui,"Voicing tocável");check(!diagram.isVisible(),"Map mode hides the fingering diagram again");
                click(ui,"Aba "+Family.PENTATONICS);
                check(find(ui,"Campo O que estudar").isVisible()&&find(ui,"Campo Visualização").isVisible()&&find(ui,"Sobrepor seleção").isVisible(),"Ordinary tabs restore every selection control");
                check(starting.getSelectedIndex()==1,"Starting-string preference survives navigation");
                formula=combo(ui,"Fórmula");
                for(Formula f:Catalog.forFamily(Family.PENTATONICS)){formula.setSelectedItem(f);check(((JPanel)state(ui,"advicePanel")).isVisible(),"Pentatonic advice exists for "+f.id());}
                click(ui,"Aba "+Family.BLUES);formula=combo(ui,"Fórmula");
                for(Formula f:Catalog.forFamily(Family.BLUES)){formula.setSelectedItem(f);check(((JPanel)state(ui,"advicePanel")).isVisible(),"Pentablues advice exists for "+f.id());}
                combo(ui,"Tônica").setSelectedItem("A");formula.setSelectedItem(Catalog.byId("blues-minor"));layout(ui);captureFullPage(ui,"docs/v1.2-improvisacao.png");
                click(ui,"Aba "+Family.MODES);check(!((JPanel)state(ui,"advicePanel")).isVisible(),"Unrelated subjects retain their ordinary tips without pentatonic advice");
                layout(ui);JScrollPane neck=(JScrollPane)find(ui,"Visualizador do braço");
                check(neck.getPreferredSize().height>=450&&neck.getMinimumSize().height>=390,"Neck viewport keeps readable vertical dimensions");
                check(neck.getViewport().getView().getPreferredSize().width>=1450,"Neck retains readable notes instead of compressing all frets");
                if(frame!=null)check(frame.isShowing(),"Desktop integration opens a real window");
            }catch(Throwable ex){failure[0]=ex;}
            finally{if(frame!=null)frame.dispose();for(Window w:Window.getWindows())w.dispose();}
        });if(failure[0]!=null)throw new AssertionError("V1.2 UI failed",failure[0]);
        System.out.println("V1.2 interface: "+checks+" checks passed.");
    }
    private static void captureFullPage(WorkspacePanel ui,String file)throws Exception{
        layout(ui);JScrollPane page=(JScrollPane)state(ui,"page");JComponent content=(JComponent)page.getViewport().getView();
        content.setSize(page.getViewport().getWidth(),content.getPreferredSize().height);layout(content);layout(content);
        BufferedImage image=new BufferedImage(content.getWidth(),content.getHeight(),BufferedImage.TYPE_INT_RGB);Graphics2D g=image.createGraphics();g.setColor(new Color(75,76,77));g.fillRect(0,0,image.getWidth(),image.getHeight());content.printAll(g);g.dispose();
        Path path=Path.of(file);Files.createDirectories(path.getParent());ImageIO.write(image,"png",path.toFile());check(Files.size(path)>10000,"Full page capture generated");
    }
    private static int row(JTable table,String key){for(int r=0;r<table.getRowCount();r++)if(key.equals(table.getValueAt(r,0)))return r;throw new AssertionError("Missing key "+key);}
    private static List<String> buttons(Container c){List<String> values=new ArrayList<>();for(Component child:c.getComponents())if(child instanceof AbstractButton b)values.add(b.getText());return values;}
    private static void layout(Container c){c.invalidate();c.doLayout();for(Component child:c.getComponents())if(child instanceof Container nested)layout(nested);}
    private static JComponent find(Container root,String name){if(root instanceof JComponent jc&&name.equals(jc.getName()))return jc;for(Component child:root.getComponents())if(child instanceof Container nested){JComponent value=find(nested,name);if(value!=null)return value;}return null;}
    @SuppressWarnings("unchecked") private static <T> JComboBox<T> combo(Container root,String name){JComponent c=find(root,name);if(c==null)throw new AssertionError("Missing "+name);return (JComboBox<T>)c;}
    private static void click(Container root,String name){JComponent c=find(root,name);if(!(c instanceof AbstractButton b))throw new AssertionError("Missing "+name);b.doClick(0);}
    private static void clickText(Container root,String text){for(Component c:root.getComponents())if(c instanceof AbstractButton b&&text.equals(b.getText())){b.doClick(0);return;}throw new AssertionError("Missing key "+text);}
    private static Object state(Object o,String name){try{Field f=o.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(o);}catch(Exception e){throw new AssertionError(e);}}
    private static void check(boolean pass,String message){checks++;if(!pass)throw new AssertionError(message);}
}
