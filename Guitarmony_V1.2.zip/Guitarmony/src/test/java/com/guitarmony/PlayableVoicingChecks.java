package com.guitarmony;

import com.guitarmony.music.*;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Full-tone grips, explicit finger assignments, common shapes and difficult tunings. */
public final class PlayableVoicingChecks {
    private static int checks;
    public static void main(String[] args) {
        Tuning standard = Tuning.standard();
        Map<List<Integer>, String> common = new HashMap<>();
        common.put(List.of(-1,3,2,0,1,0), "C aberto");
        common.put(List.of(0,2,2,1,0,0), "E aberto");
        common.put(List.of(-1,0,2,2,2,0), "A aberto com minipestana");
        common.put(List.of(1,3,3,2,1,1), "F com pestana");
        common.put(List.of(-1,2,4,4,4,2), "B com pestana");
        common.put(List.of(-1,-1,0,2,3,2), "D aberto");
        for (var example : common.entrySet()) {
            var plan = GripFingering.forFrets(example.getKey());
            check(plan.isPresent(), example.getValue() + " precisa ser reconhecido");
            validateFingers(example.getKey(),plan.orElseThrow());
        }
        check(GripFingering.forFrets(List.of(0,7,9,9,9,0)).isEmpty(), "não sugerir posição alta com cordas soltas");
        check(GripFingering.forFrets(List.of(-1,1,5,3,4,1)).isEmpty(), "não sugerir alcance de cinco casas na primeira posição");
        check(GripFingering.forFrets(List.of(1,2,3,4,3,2)).isEmpty(), "não aceitar seis contatos sem pestana possível com quatro dedos");
        check(GripFingering.forFrets(List.of(-1,0,0,0,-1,-1)).orElseThrow().fingerCount() == 0, "cordas abertas não gastam dedos");
        equal(List.of(1,0,0,4,0,0),GripFingering.forFrets(List.of(1,-1,-1,4,-1,-1)).orElseThrow().fingers(),
                "salto primeira-quarta casa usa indicador e mínimo, em vez de forçar dedos adjacentes");
        List<Tuning> tunings = List.of(standard, standard.shiftString(0,-2),
                Tuning.presets().get("DADGAD · D A D G A D"), new Tuning(52,45,50,55,59,64));
        List<String> formulas = List.of("triad-major","triad-minor","triad-dim","triad-aug","maj7","dom7","halfdim7","dim7");
        for (Tuning tuning : tunings) for (String root : List.of("C","E","F#"))
            for (String id : formulas) for (int target : List.of(0,7,17)) {
                Formula formula = Catalog.byId(id);
                List<Voicing> shapes = VoicingEngine.find(root,formula,tuning,target);
                check(!shapes.isEmpty(), "nenhum voicing para " + root + "/" + id + "/" + target);
                check(shapes.size() <= 8, "limite de resultados");
                Set<List<Integer>> unique = new HashSet<>();
                for (Voicing shape : shapes) {
                    check(unique.add(shape.frets()), "sem duplicatas");
                    Set<Integer> pitches = new HashSet<>();
                    int low = 25, high = 0, open = 0, actualBassMidi = Integer.MAX_VALUE, actualBassPitch = -1;
                    for (int string = 0; string < 6; string++) {
                        int fret = shape.frets().get(string);
                        if (fret < 0) continue;
                        pitches.add(Math.floorMod(tuning.pitchAt(string,fret)-Notes.pitch(root),12));
                        equal(tuning.pitchAt(string,fret),Notes.pitch(shape.notes().get(string)),"rótulo respeita afinação");
                        if (fret == 0) open++;
                        else { low = Math.min(low,fret); high = Math.max(high,fret); }
                        if (tuning.midiAt(string,fret) < actualBassMidi) {
                            actualBassMidi = tuning.midiAt(string,fret); actualBassPitch = tuning.pitchAt(string,fret);
                        }
                    }
                    equal(new HashSet<>(formula.intervals()),pitches,"preservar TODAS as alturas do acorde");
                    check(high == 0 || high-low <= (low < 5 ? 3 : 4),"abertura compacta segundo região");
                    check(open == 0 || high <= 5,"posição aberta perto da pestana do instrumento");
                    boolean rootBass = actualBassPitch == Notes.pitch(root);
                    check(rootBass == shape.label().startsWith("Tônica no baixo"),"inversão considera o baixo MIDI real, inclusive afinação reentrante");
                    validateFingers(shape.frets(),shape.fingering().orElseThrow());
                }
            }
        List<Voicing> c = VoicingEngine.find("C",Catalog.byId("triad-major"),standard,0);
        check(c.stream().anyMatch(v -> v.frets().equals(List.of(-1,3,2,0,1,0))),"C aberto entre as opções próximas");
        check(c.stream().anyMatch(v -> v.label().startsWith("Inversão")),"inversões fáceis continuam disponíveis");
        check(c.get(0).frets().stream().filter(f -> f > 0).mapToInt(Integer::intValue).max().orElse(0) <= 3,"preferir uma opção próxima e simples");
        Voicing easyF7 = VoicingEngine.find("F",Catalog.byId("dom7"),standard,0).get(0);
        check(easyF7.fingering().orElseThrow().fingerCount() <= 2,"F7 próximo começa pela inversão confortável de dois dedos");
        int f7Low = easyF7.frets().stream().filter(f -> f > 0).mapToInt(Integer::intValue).min().orElseThrow();
        int f7High = easyF7.frets().stream().filter(f -> f > 0).mapToInt(Integer::intValue).max().orElseThrow();
        check(f7High-f7Low <= 1,"F7 simples conserva abertura de no máximo uma casa");
        Set<Integer> f7Pitches = new HashSet<>();
        for (int string = 0; string < 6; string++) if (easyF7.frets().get(string) >= 0)
            f7Pitches.add(standard.pitchAt(string,easyF7.frets().get(string)));
        equal(Set.of(5,9,0,3),f7Pitches,"F7 fácil mantém F, A, C e Eb completos");
        List<Voicing> high = VoicingEngine.find("C",Catalog.byId("maj7"),standard,17);
        check(high.get(0).frets().stream().filter(f -> f > 0).mapToInt(Integer::intValue).min().orElse(0) >= 12,"respeitar a região alta solicitada");
        check(VoicingEngine.find("C",Catalog.byId("triad-major"),new Tuning(48,48,48,48,48,48),0).isEmpty(),
                "sem solução ergonômica em afinação uníssona: não retirar notas para fabricar um acorde");
        equal(c,VoicingEngine.find("C",Catalog.byId("triad-major"),standard,0),"cache mantém os resultados");
        check(VoicingEngine.find("C",Catalog.byId("major"),standard,0).isEmpty(),"escala não se transforma em tríade incompleta");
        System.out.println("Playable voicing checks: " + checks + " assertions passed.");
    }

    private static void validateFingers(List<Integer> frets, GripFingering.Plan plan) {
        check(plan.fingerCount() <= 4,"no máximo quatro dedos");
        Map<Integer,Integer> assignedFret = new HashMap<>();
        for (int string = 0; string < 6; string++) {
            int finger = plan.fingers().get(string), fret = frets.get(string);
            if (fret <= 0) equal(0,finger,"corda aberta ou abafada sem pressão");
            else {
                check(finger >= 1 && finger <= 4,"nota presa tem dedo válido");
                Integer previous = assignedFret.putIfAbsent(finger,fret);
                check(previous == null || previous == fret,"um dedo não ocupa casas diferentes");
            }
        }
        for (GripFingering.Barre barre : plan.barres()) {
            check(barre.firstString() < barre.lastString(),"pestana cobre mais de uma corda");
            for (int string = barre.firstString(); string <= barre.lastString(); string++)
                check(frets.get(string) >= barre.fret(),"pestana não cruza corda solta, abafada ou casa mais baixa");
        }
        equal(plan.fingerCount(),assignedFret.size(),"contagem corresponde aos dedos usados");
    }
    private static void check(boolean valid,String message) { checks++; if (!valid) throw new AssertionError(message); }
    private static void equal(Object a,Object b,String message) { check(a.equals(b),message + ": " + a + " / " + b); }
}
