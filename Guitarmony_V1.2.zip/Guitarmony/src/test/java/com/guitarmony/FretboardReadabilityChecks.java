package com.guitarmony;

import com.guitarmony.fretboard.Cell;
import com.guitarmony.fretboard.ShapeEngine;
import com.guitarmony.music.Catalog;
import com.guitarmony.music.Formula;
import com.guitarmony.music.Tuning;
import com.guitarmony.ui.FretboardPanel;
import com.guitarmony.ui.Layer;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import javax.swing.JViewport;
import javax.swing.SwingUtilities;

/** User-facing regressions: readable neck, line-free strings and preserved hit targets. */
public final class FretboardReadabilityChecks {
    private static int assertions;
    public static void main(String[] args) throws Exception {
        SwingUtilities.invokeAndWait(() -> {
            FretboardPanel p = new FretboardPanel();
            check(p.getPreferredSize().height >= 440, "braço mantém altura ampliada");
            check(p.getMinimumSize().height >= 380, "altura mínima evita achatamento");
            JViewport viewport = new JViewport(); viewport.setView(p);
            viewport.setSize(1000,450);
            check(!p.getScrollableTracksViewportWidth(), "janela menor permite rolagem, sem miniaturizar as notas");
            viewport.setSize(1920,450);
            check(p.getScrollableTracksViewportWidth(), "janela ampla exibe o braço integral");
            for (int width : new int[]{1450,1920}) {
                p.setSize(width,FretboardPanel.PREFERRED_HEIGHT);
                p.setData(Tuning.standard(),List.of(),true,false,false,false);
                BufferedImage empty = render(p);
                // Open-string strip is uniform ivory; a drawn string would cross
                // and visibly change this strip at each of the six row centres.
                for(int string=0;string<6;string++) {
                    int cy=y(string,p.getHeight());
                    int expected=empty.getRGB(60,cy-5);
                    for(int dy=-3;dy<=3;dy++) check(empty.getRGB(60,cy+dy)==expected,"sem linhas de cordas no modo realista");
                }
                AtomicReference<Cell> clicked = new AtomicReference<>(); p.setCellListener(clicked::set);
                for(int string=0;string<6;string++) for(int fret=0;fret<=24;fret++) {
                    int cx=x(fret,width),cy=y(string,p.getHeight());
                    p.dispatchEvent(new MouseEvent(p,MouseEvent.MOUSE_CLICKED,0,0,cx,cy,1,false));
                    check(new Cell(string,fret).equals(clicked.get()),"clique identifica corda/casa em braço ampliado");
                    String tip=p.getToolTipText(new MouseEvent(p,MouseEvent.MOUSE_MOVED,0,0,cx,cy,0,false));
                    check(tip!=null && tip.contains((6-string)+"ª corda"),"dica preserva corda");
                    check(tip.contains(fret==0?"corda solta":"casa "+fret),"dica preserva a casa24 inclusive");
                }
                p.setData(Tuning.standard(),List.of(),false,false,false,true);
                BufferedImage notes=render(p);
                int cx=x(0,width),cy=y(5,p.getHeight());
                int glyphMin=10000,glyphMax=-1;
                for(int yy=cy-15;yy<=cy+15;yy++) for(int xx=cx-9;xx<=cx+9;xx++) {
                    Color c=new Color(notes.getRGB(xx,yy),true);
                    if(c.getAlpha()>240 && c.getRed()<65 && c.getGreen()<65 && c.getBlue()<75) { glyphMin=Math.min(glyphMin,yy);glyphMax=Math.max(glyphMax,yy); }
                }
                check(glyphMax-glyphMin+1>=11,"rótulo E tem altura visível de fonte16, sem redução");
                int cy0=y(0,p.getHeight());
                Color markerEdge=new Color(notes.getRGB(cx+17,cy0),true);
                check(markerEdge.getRed()>210 && markerEdge.getAlpha()>240,"marcador ampliado alcança raio18 ou maior");
                Formula cMajor=Catalog.byId("ionian");Tuning t=Tuning.standard();
                Layer c=new Layer("Dó jônio","C",cMajor,ShapeEngine.allNotes(cMajor,0,t),new Color(0xD9BCF4));
                Layer e=new Layer("Mi jônio","E",cMajor,ShapeEngine.allNotes(cMajor,4,t),new Color(0xF6C061));
                for(boolean realistic:new boolean[]{false,true}) {
                    p.setData(t,List.of(c,e),realistic,false,false,true);
                    BufferedImage overlap=render(p);
                    Color tonic=new Color(overlap.getRGB(cx+10,cy0+9),true);
                    check(tonic.getGreen()>tonic.getRed()*2 && tonic.getGreen()>tonic.getBlue()*1.4,"tônica permanece verde sob camadas em ambos estilos");
                }
            }
        });
        System.out.println("PASSOU  Braço ampliado, legibilidade, 150 alvos e ausência de cordas: "+assertions+" verificações");
    }
    private static int x(int fret,int width){return (int)Math.round(46+(width-64)/25.0*(fret+.5));}
    private static int y(int string,int height){return (int)Math.round(52+(height-110)/6.0*(5-string+.5));}
    private static BufferedImage render(FretboardPanel p){
        BufferedImage image=new BufferedImage(p.getWidth(),p.getHeight(),BufferedImage.TYPE_INT_ARGB);
        Graphics2D g=image.createGraphics();p.paint(g);g.dispose();return image;
    }
    private static void check(boolean ok,String message){assertions++;if(!ok)throw new AssertionError(message);}
}
