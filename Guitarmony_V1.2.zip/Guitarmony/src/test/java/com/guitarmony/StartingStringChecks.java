package com.guitarmony;

import com.guitarmony.fretboard.Cell;
import com.guitarmony.fretboard.Position;
import com.guitarmony.fretboard.ShapeEngine;
import com.guitarmony.music.Catalog;
import com.guitarmony.music.Formula;
import com.guitarmony.music.Tuning;
import com.guitarmony.ui.FretboardPanel;
import com.guitarmony.ui.Layer;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

/** Regression checks for tonic-led construction on any of the six strings. */
public final class StartingStringChecks {
    private static int assertions;
    public static void main(String[] args) throws Exception {
        Tuning standard = Tuning.standard();
        Formula ionian = Catalog.byId("ionian");
        Position a = ShapeEngine.shape(ionian, 9, standard, 0, 1);
        check(a.cells().size() == 15, "Jônio em Lá usa cinco cordas a partir da 5ª");
        check(a.cells().containsAll(Set.of(new Cell(1, 0), new Cell(1, 2), new Cell(1, 4))), "Lá, Si, Dó# na corda Lá");
        check(a.cells().containsAll(Set.of(new Cell(4, 2), new Cell(4, 3), new Cell(4, 5))), "passagem Sol/Si conserva afinação real");
        List<Formula> formulas = List.of(ionian, Catalog.byId("dorian"), Catalog.byId("penta-minor"),
                Catalog.byId("penta-major"), Catalog.byId("blues-minor"), Catalog.byId("harmonic-minor"), Catalog.byId("maj7"));
        for (Tuning tuning : Tuning.presets().values()) for (int start = 0; start < 6; start++) {
            for (Formula f : formulas) for (int root = 0; root < 12; root++) for (int anchor : new int[]{0, 12, 24}) {
                Position p = ShapeEngine.shape(f, root, tuning, anchor, start);
                verify(p, tuning, start);
                for (Position step : ShapeEngine.sequence(f, root, tuning, anchor, start)) verify(step, tuning, start);
            }
            for (int root = 0; root < 12; root++) {
                for (int box = 0; box < 5; box++) verify(ShapeEngine.boxShape(Catalog.byId("penta-minor"),root,tuning,12,box,start),tuning,start);
            }
        }
        for (int start = 0; start < 6; start++) {
            Position p = ShapeEngine.shape(ionian, 0, standard, 0, start);
            List<Cell> ordered = p.cells().stream().sorted(Comparator.comparingInt(Cell::stringIndex).thenComparingInt(Cell::fret)).toList();
            int previous = -1;
            for (Cell c : ordered) {
                int midi = standard.midiAt(c.stringIndex(), c.fret());
                check(midi > previous, "linha melódica ascende pelas cordas"); previous = midi;
            }
        }
        try { ShapeEngine.shape(ionian, 0, standard, 0, 6); throw new AssertionError("Corda inexistente aceita"); }
        catch (IllegalArgumentException expected) { assertions++; }
        javax.swing.SwingUtilities.invokeAndWait(StartingStringChecks::greenTonics);
        System.out.println("PASSOU  Corda inicial, notas físicas e tônicas verdes: " + assertions + " verificações");
    }
    private static void verify(Position p, Tuning tuning, int start) {
        check(!p.cells().isEmpty(), "posição válida contém notas");
        for (Cell c : p.cells()) {
            check(c.stringIndex() >= start, "não toca corda anterior à selecionada");
            check(p.formula().contains(Math.floorMod(tuning.pitchAt(c.stringIndex(),c.fret())-p.rootPitch(),12)), "nota pertence ao estudo");
        }
    }
    private static void greenTonics() {
        Formula f = Catalog.byId("ionian"); Tuning t = Tuning.standard();
        Layer l = new Layer("Mi jônio", "E", f, ShapeEngine.allNotes(f,4,t), new Color(0xAB67DD));
        FretboardPanel panel = new FretboardPanel(); panel.setSize(1180,300);
        for (boolean realistic : new boolean[]{false,true}) {
            panel.setData(t,List.of(l),realistic,false,false,true);
            BufferedImage im = new BufferedImage(1180,300,BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = im.createGraphics(); panel.paint(g); g.dispose();
            int green = 0;
            for (int y=0;y<im.getHeight();y++) for (int x=0;x<im.getWidth();x++) {
                Color c = new Color(im.getRGB(x,y),true);
                if(c.getAlpha()>240 && c.getGreen()>70 && c.getGreen()>c.getRed()*1.7 && c.getGreen()>c.getBlue()*1.3) green++;
            }
            check(green>1000,"tônicas têm preenchimento verde em ambos os estilos");
        }
    }
    private static void check(boolean condition,String message) {
        assertions++; if(!condition) throw new AssertionError(message);
    }
}
