package com.guitarmony;

import com.guitarmony.music.*;
import java.util.HashSet;
import java.util.List;

/** Checks screen spelling independently from the retained theoretical spelling. */
public final class TheoryDisplayChecks {
    private static int checks;

    public static void main(String[] args) {
        equal("F", Notes.displayName("E#"));
        equal("E", Notes.displayName("Fb"));
        equal("C", Notes.displayName("B#"));
        equal("B", Notes.displayName("Cb"));
        equal(List.of("F#", "G#", "A#", "B", "C#", "D#", "F"),
                Notes.display("F#", Catalog.byId("major")));
        equal("E#", Notes.spell("F#", Catalog.byId("major")).get(6));
        for (Family family : Family.values()) {
            for (Formula formula : Catalog.forFamily(family)) {
                for (String root : Notes.roots()) {
                    for (boolean flats : new boolean[]{false, true}) {
                        List<String> display = Notes.display(root, formula, flats);
                        for (int i = 0; i < display.size(); i++) {
                            String note = display.get(i);
                            check(!List.of("E#", "Fb", "B#", "Cb").contains(note), "Uncommon label " + note);
                            check(note.length() <= 2, "Double accidental " + note);
                            equal(Math.floorMod(Notes.pitch(root) + formula.intervals().get(i), 12), Notes.pitch(note));
                            if (flats) check(!note.contains("#"), "Flat preference ignored");
                        }
                    }
                }
            }
        }
        for (Formula scale : Harmony.fieldScales()) {
            for (String root : Notes.displayRoots()) {
                for (boolean sevenths : new boolean[]{false, true}) {
                    List<HarmonicChord> theory = Harmony.harmonize(root, scale, sevenths);
                    List<HarmonicChord> screen = Harmony.displayHarmonize(root, scale, sevenths);
                    equal(7, screen.size());
                    for (int i = 0; i < 7; i++) {
                        equal(theory.get(i).formula(), screen.get(i).formula());
                        equal(theory.get(i).roman(), screen.get(i).roman());
                        equal(Notes.pitch(theory.get(i).root()), Notes.pitch(screen.get(i).root()));
                        for (int t = 0; t < screen.get(i).notes().size(); t++)
                            equal(Notes.pitch(theory.get(i).notes().get(t)), Notes.pitch(screen.get(i).notes().get(t)));
                    }
                }
            }
        }
        equal(List.of("Am", "Bdim", "C+", "Dm", "E", "F", "G#dim"),
                Harmony.displayHarmonize("A", Catalog.byId("harmonic-minor"), false).stream()
                        .map(HarmonicChord::name).toList());
        equal(12, new HashSet<>(CircleOfFifths.keys().stream().map(CircleOfFifths.Key::pitch).toList()).size());
        for (CircleOfFifths.Key key : CircleOfFifths.keys()) {
            equal(Math.floorMod(key.pitch() + 7, 12), CircleOfFifths.next(key.major()).pitch());
            equal(Math.floorMod(key.pitch() + 5, 12), CircleOfFifths.previous(key.major()).pitch());
            equal(Math.floorMod(key.pitch() + 9, 12), Notes.pitch(key.relativeMinorRoot()));
        }
        equal("B", CircleOfFifths.forPitch(Notes.pitch("Cb")).major());
        System.out.println("Theory display checks: " + checks + " assertions passed.");
    }

    private static void check(boolean valid, String description) {
        checks++;
        if (!valid) throw new AssertionError(description);
    }

    private static void equal(Object expected, Object actual) {
        check(expected.equals(actual), "Expected " + expected + ", got " + actual);
    }
}
