package com.guitarmony;

import com.guitarmony.music.*;
import com.guitarmony.ui.ChordDiagramPanel;
import javax.swing.SwingUtilities;
import java.awt.image.BufferedImage;
import java.awt.Graphics2D;
import java.nio.file.*;
import java.util.*;
import javax.imageio.ImageIO;

/** Checks renderable complete shapes, open/muted strings and an upper-neck inversion. */
public final class ChordDiagramChecks {
    private static int checks;
    public static void main(String[] args)throws Exception {
        Throwable[] failure={null};
        SwingUtilities.invokeAndWait(()->{try{
            ChordDiagramPanel panel=new ChordDiagramPanel();panel.setSize(274,340);
            for(String root:List.of("C","F#","Bb","A")){
                var chord=Harmony.displayHarmonize(root,Catalog.byId("major"),true).get(0);
                var choices=VoicingEngine.find(root,chord.formula(),Tuning.standard(),root.equals("Bb")?10:0);
                check(!choices.isEmpty(),"Complete chord shape available");
                for(var shape:choices){
                    panel.setChord(chord,shape,Tuning.standard(),true);
                    BufferedImage image=new BufferedImage(274,340,BufferedImage.TYPE_INT_RGB);Graphics2D g=image.createGraphics();panel.paint(g);g.dispose();
                    int rootPixels=0;for(int y=60;y<image.getHeight()-35;y++)for(int x=25;x<image.getWidth();x++){int rgb=image.getRGB(x,y);if(((rgb>>8)&255)>80&&((rgb>>16)&255)<30&&(rgb&255)<100)rootPixels++;}
                    check(rootPixels>0,"Green chord tonic visible, including open strings");
                    check(panel.getAccessibleContext().getAccessibleDescription().contains(chord.name()),"Chord identified for nonvisual reading");
                    check(panel.getToolTipText().contains("sexta"),"String order explained");
                    Set<Integer> pitches=new HashSet<>();for(int s=0;s<6;s++)if(shape.frets().get(s)>=0)pitches.add(Tuning.standard().pitchAt(s,shape.frets().get(s)));
                    check(pitches.size()==chord.formula().intervals().size(),"Preview retains every distinct chord tone");
                    if(root.equals("C")&&shape.equals(choices.get(0))){Files.createDirectories(Path.of("build"));ImageIO.write(image,"png",Path.of("build/chord-diagram.png").toFile());}
                }
            }
            panel.setChord(null,null,Tuning.standard(),false);BufferedImage empty=new BufferedImage(274,340,BufferedImage.TYPE_INT_RGB);Graphics2D g=empty.createGraphics();panel.paint(g);g.dispose();check(panel.getToolTipText().contains("Escolha"),"Empty state is readable");
        }catch(Throwable ex){failure[0]=ex;}});
        if(failure[0]!=null)throw new AssertionError(failure[0]);
        System.out.println("Chord diagrams: "+checks+" checks passed.");
    }
    private static void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
}
