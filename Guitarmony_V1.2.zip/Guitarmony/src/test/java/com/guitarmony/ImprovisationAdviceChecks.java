package com.guitarmony;

import com.guitarmony.music.*;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Verify advice is transposed, contextual, and its phrase endings are chord tones. */
public final class ImprovisationAdviceChecks {
    private static int checks;
    private static final Pattern CHORD = Pattern.compile("^([A-G][#b]?)(.*)$");
    public static void main(String[] args) {
        for (Family family : List.of(Family.PENTATONICS,Family.BLUES))
            for (Formula formula : Catalog.forFamily(family)) for (int root = 0; root < 12; root++)
                for (boolean flats : new boolean[]{false,true}) {
                    String rootName = Notes.chromatic(root,flats);
                    var advice = ImprovisationAdvice.forSelection(rootName,formula,flats).orElseThrow();
                    check(!advice.context().isBlank() && !advice.phraseTip().isBlank() && !advice.caution().isBlank(),"lição completa");
                    check(!advice.targets().isEmpty() && !advice.progressions().isEmpty(),"acordes e progressões presentes");
                    Set<Integer> selected = new HashSet<>();
                    for (int interval : formula.intervals()) selected.add((root+interval)%12);
                    for (var target : advice.targets()) {
                        Matcher matcher = CHORD.matcher(target.chord());
                        check(matcher.matches(),"nome de acorde válido " + target.chord());
                        int chordRoot = Notes.pitch(matcher.group(1));
                        List<Integer> intervals = switch (matcher.group(2)) {
                            case "" -> List.of(0,4,7);
                            case "m" -> List.of(0,3,7);
                            case "m7" -> List.of(0,3,7,10);
                            case "7" -> List.of(0,4,7,10);
                            case "m6" -> List.of(0,3,7,9);
                            case "m7(b5)" -> List.of(0,3,6,10);
                            default -> throw new AssertionError("Acorde desconhecido: " + target.chord());
                        };
                        Set<Integer> chord = new HashSet<>();
                        for (int interval : intervals) chord.add((chordRoot+interval)%12);
                        check(!target.endingNotes().isEmpty(),"notas de repouso presentes");
                        for (String note : target.endingNotes()) {
                            check(selected.contains(Notes.pitch(note)),"repouso existe na seleção");
                            check(chord.contains(Notes.pitch(note)),"repouso é nota real do acorde");
                            check(!List.of("E#","B#","Fb","Cb").contains(note),"grafia prática");
                            if (flats) check(!note.contains("#"),"preferência de bemóis respeitada");
                        }
                        check(!target.explanation().isBlank(),"alvo explicado");
                    }
                }
        var minor = ImprovisationAdvice.forSelection("E",Catalog.byId("penta-minor"),false).orElseThrow();
        check(minor.caution().contains("G") && minor.caution().contains("G#") && minor.caution().contains("contrasta"),"explicar terça menor de E contra terça maior de E7");
        var e7 = minor.targets().stream().filter(t -> t.chord().equals("E7")).findFirst().orElseThrow();
        check(!e7.endingNotes().contains("G"),"terça menor não é falsamente chamada de nota do E7");
        var halfdim = ImprovisationAdvice.forSelection("B",Catalog.byId("penta-halfdim"),false).orElseThrow();
        check(halfdim.progressions().contains("Bm7(b5) → E7 → Am"),"cadência iiø V i transposta corretamente");
        var bluesHalfdim = ImprovisationAdvice.forSelection("B",Catalog.byId("blues-halfdim"),false).orElseThrow();
        check(bluesHalfdim.caution().contains("quinta justa") && bluesHalfdim.caution().contains("não substitui"),"quinta cromática preservada e explicada");
        var major = ImprovisationAdvice.forSelection("C",Catalog.byId("blues-major"),false).orElseThrow();
        check(major.caution().contains("Eb") || major.caution().contains("D#"),"blue note maior identificada");
        check(ImprovisationAdvice.forSelection("C",Catalog.byId("major"),false).isEmpty(),"sem lição de pentatônica para escala maior");
        System.out.println("Improvisation advice checks: " + checks + " assertions passed.");
    }
    private static void check(boolean valid,String message) { checks++; if (!valid) throw new AssertionError(message); }
}
