package com.guitarmony.music;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** Contextual practice suggestions. They neither replace the scale nor impose rules. */
public final class ImprovisationAdvice {
    public record Target(String chord, List<String> endingNotes, String explanation) {
        public Target { endingNotes = List.copyOf(endingNotes); }
    }
    public record Advice(String context, List<Target> targets, List<String> progressions,
                         String phraseTip, String caution) {
        public Advice { targets = List.copyOf(targets); progressions = List.copyOf(progressions); }
    }
    private record Chord(int offset, String suffix, List<Integer> intervals) {}
    private static final List<Integer> MAJOR = List.of(0,4,7);
    private static final List<Integer> MINOR = List.of(0,3,7);
    private static final List<Integer> MIN7 = List.of(0,3,7,10);
    private static final List<Integer> DOM7 = List.of(0,4,7,10);
    private static final List<Integer> MIN6 = List.of(0,3,7,9);
    private static final List<Integer> HALFDIM = List.of(0,3,6,10);
    private ImprovisationAdvice() {}

    public static Optional<Advice> forSelection(String root, Formula formula) {
        return forSelection(root, formula, false);
    }

    public static Optional<Advice> forSelection(String root, Formula formula, boolean preferFlats) {
        if (formula.family() != Family.PENTATONICS && formula.family() != Family.BLUES)
            return Optional.empty();
        Builder b = new Builder(root, formula, preferFlats);
        return switch (formula.id()) {
            case "penta-major", "blues-major" -> {
                boolean blues = formula.id().equals("blues-major");
                b.target(0,"",MAJOR,"Tônica, terça e quinta podem dar uma sensação de chegada sobre esse acorde.");
                b.target(9,"m",MINOR,"A relativa menor compartilha essas notas; experimente mudar a nota de repouso.");
                b.target(5,"",MAJOR,"Estas notas pertencem tanto à seleção quanto ao acorde IV; a frase pode acompanhar a mudança.");
                b.progression(new Chord(0,"",MAJOR),new Chord(5,"",MAJOR),new Chord(7,"",MAJOR),new Chord(0,"",MAJOR));
                b.progression(new Chord(0,"",MAJOR),new Chord(9,"m",MINOR),new Chord(5,"",MAJOR),new Chord(7,"",MAJOR));
                yield Optional.of(b.advice("Pode funcionar em contextos maiores, pop, country e blues maior. A base e o acorde do momento orientam o resultado.",
                        "Uma frase pode experimentar " + b.line(2,0) + " ou " + b.line(9,7) + ", seguida de uma pausa sobre o acorde de tônica.",
                        blues ? "A blue note " + b.note(3) + " colore a terça maior " + b.note(4) + "; você pode usá-la como aproximação. Ela não transforma o acorde maior em menor."
                                : "A sexta e a segunda podem soar como cores sobre a tríade. Os pontos de chegada são sugestões; ritmo, ouvido e contexto decidem."));
            }
            case "penta-minor", "blues-minor" -> {
                boolean blues = formula.id().equals("blues-minor");
                b.target(0,"m7",MIN7,"As notas do acorde podem servir de repouso em um contexto menor.");
                b.target(5,"m",MINOR,"Notas em comum com o iv menor podem destacar a troca de acorde.");
                b.target(0,"7",DOM7,"Em blues, estes são pontos de chegada do acorde dominante que também estão na seleção; a terça menor acrescenta outra cor.");
                b.progression(new Chord(0,"m",MINOR),new Chord(5,"m",MINOR),new Chord(7,"7",DOM7),new Chord(0,"m",MINOR));
                b.progression(new Chord(0,"7",DOM7),new Chord(5,"7",DOM7),new Chord(7,"7",DOM7),new Chord(0,"7",DOM7));
                yield Optional.of(b.advice("Experimente em bases menores. Sobre acordes dominantes de blues, a terça menor funciona como uma cor expressiva, não como compatibilidade diatônica exata.",
                        "Uma frase pode repousar em " + b.line(3,0) + " ou " + b.line(5,7) + "; sobre cada acorde, ouça os pontos de chegada sugeridos.",
                        "Sobre " + b.chord(0,"7") + ", " + b.note(3) + " é a terça menor e contrasta com a terça maior " + b.note(4) + " do acorde."
                                + (blues ? " A blue note " + b.note(6) + " pode passar para " + b.note(5) + " ou " + b.note(7) + ", sem precisar virar repouso." : " Esse contraste faz parte da linguagem do blues; não é uma regra para toda base maior.")));
            }
            case "penta-minor6" -> {
                b.target(0,"m6",MIN6,"A sexta faz parte do acorde menor com sexta e pode destacar essa sonoridade.");
                b.target(5,"7",DOM7,"O IV7 compartilha estas notas com a seleção e pode sugerir uma base dórica.");
                b.progression(new Chord(0,"m6",MIN6),new Chord(5,"7",DOM7),new Chord(0,"m6",MIN6));
                yield Optional.of(b.advice("Pode sugerir uma cor dórica ou menor com sexta maior, especialmente em um vamp i menor–IV7.",
                        "Uma frase pode destacar " + b.line(9,7) + " e terminar em " + b.note(3) + " ou " + b.note(0) + " sobre " + b.chord(0,"m6") + ".",
                        "A sexta maior " + b.note(9) + " diferencia esta seleção da pentatônica menor comum. Confira a base: a sexta menor de outra harmonia pode criar atrito."));
            }
            case "penta-dominant", "blues-dominant" -> {
                boolean blues = formula.id().equals("blues-dominant");
                b.target(0,"7",DOM7,"Tônica, terça maior, quinta e sétima menor são pontos possíveis de repouso sobre o acorde 7.");
                b.target(5,"",MAJOR,"Quando o acorde 7 resolve uma quarta acima, estas notas em comum podem acompanhar a chegada.");
                b.progression(new Chord(0,"7",DOM7),new Chord(5,"",MAJOR));
                b.progression(new Chord(0,"7",DOM7),new Chord(5,"7",DOM7),new Chord(7,"7",DOM7),new Chord(0,"7",DOM7));
                yield Optional.of(b.advice("Pode funcionar sobre " + b.chord(0,"7") + " em blues ou em uma resolução dominante. Um acorde 7 nem sempre exerce a função de V grau.",
                        "Experimente " + b.line(5,4) + " para aproximar a terça maior, ou uma chegada em " + b.note(10) + " ou " + b.note(0) + " sobre o acorde 7.",
                        "A quarta " + b.note(5) + " pode tensionar a terça maior " + b.note(4) + "."
                                + (blues ? " A blue note " + b.note(6) + " pode conduzir para " + b.note(5) + " ou " + b.note(7) + "; ela não precisa ser sustentada." : " Você pode resolver esse movimento pelo ouvido, sem retirar nenhuma nota da seleção.")));
            }
            case "penta-halfdim", "blues-halfdim" -> {
                boolean blues = formula.id().equals("blues-halfdim");
                b.target(0,"m7(b5)",HALFDIM,"Tônica, terça menor, quinta diminuta e sétima menor definem o acorde meio-diminuto.");
                b.target(5,"7",DOM7,"Na cadência iiø–V7–i, estas notas em comum podem guiar a passagem pelo dominante.");
                b.target(10,"m",MINOR,"Estes pontos de chegada pertencem ao i menor dessa cadência e também à seleção atual.");
                b.progression(new Chord(0,"m7(b5)",HALFDIM),new Chord(5,"7",DOM7),new Chord(10,"m",MINOR));
                yield Optional.of(b.advice("Pode ser explorada sobre " + b.chord(0,"m7(b5)") + ", por exemplo como iiø de uma cadência que chega a " + b.chord(10,"m") + ".",
                        "Uma frase pode destacar " + b.line(5,6) + " e repousar em " + b.note(3) + " ou " + b.note(0) + " sobre o meio-diminuto.",
                        blues ? "Esta pentablues inclui quinta diminuta " + b.note(6) + " e quinta justa " + b.note(7) + ". A quinta justa acrescenta passagem cromática; não substitui a quinta diminuta do acorde."
                                : "A quarta " + b.note(5) + " acrescenta cor ao acorde. Uma seleção sobre o iiø não garante todas as notas dos acordes seguintes; ouça a mudança e use os pontos em comum."));
            }
            default -> Optional.empty();
        };
    }

    private static final class Builder {
        private final int root;
        private final Formula formula;
        private final boolean flats;
        private final List<String> scaleNames;
        private final List<Target> targets = new ArrayList<>();
        private final List<String> progressions = new ArrayList<>();
        Builder(String root, Formula formula, boolean flats) {
            this.root = Notes.pitch(root); this.formula = formula;
            this.flats = flats || root.contains("b") || root.contains("♭");
            scaleNames = Notes.display(root, formula, flats);
        }
        String note(int interval) {
            int index = formula.intervals().indexOf(Math.floorMod(interval,12));
            return index >= 0 ? scaleNames.get(index) : Notes.chromatic(root + interval, flats);
        }
        String chord(int offset, String suffix) { return note(offset) + suffix; }
        String line(int from, int to) { return note(from) + " → " + note(to); }
        void target(int offset, String suffix, List<Integer> chordIntervals, String explanation) {
            List<String> common = chordIntervals.stream().map(i -> Math.floorMod(offset + i,12))
                    .filter(formula.intervals()::contains).map(this::note).distinct().toList();
            if (common.isEmpty()) throw new IllegalArgumentException("O alvo precisa compartilhar alguma nota com a seleção.");
            targets.add(new Target(chord(offset,suffix),common,explanation));
        }
        void progression(Chord... chords) {
            progressions.add(java.util.Arrays.stream(chords).map(c -> chord(c.offset(),c.suffix()))
                    .collect(java.util.stream.Collectors.joining(" → ")));
        }
        Advice advice(String context, String phraseTip, String caution) {
            return new Advice(context,targets,progressions,phraseTip,caution);
        }
    }
}
