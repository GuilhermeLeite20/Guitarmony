package com.guitarmony.music;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/** Conservative four-finger model for the compact grips offered by the app. */
public final class GripFingering {
    public record Barre(int finger, int fret, int firstString, int lastString) {}
    public record Plan(List<Integer> fingers, List<Barre> barres, int fingerCount, double effort) {
        public Plan { fingers = List.copyOf(fingers); barres = List.copyOf(barres); }
    }
    private record Contact(int fret, int first, int last, int mask) {
        boolean barre() { return first != last; }
    }
    private GripFingering() {}

    /** Finger 0 means an open or muted string. No thumb-over-the-neck grips. */
    public static Optional<Plan> forFrets(List<Integer> frets) {
        if (frets.size() != 6 || frets.stream().anyMatch(f -> f < -1 || f > 24))
            throw new IllegalArgumentException("Informe seis casas entre -1 e 24.");
        int low = 25, high = 0, mask = 0;
        boolean open = false;
        for (int string = 0; string < 6; string++) {
            int fret = frets.get(string);
            if (fret == 0) open = true;
            if (fret > 0) { low = Math.min(low, fret); high = Math.max(high, fret); mask |= 1 << string; }
        }
        if (mask == 0) return Optional.of(new Plan(List.of(0,0,0,0,0,0), List.of(), 0, 0));
        // At the nut four frets already require a large reach. Higher up, frets narrow.
        if (high - low > (low < 5 ? 3 : 4) || fretDistance(low, high) > 110) return Optional.empty();
        // Restrict the suggestions to ordinary open-position grips, rather than drone shapes.
        if (open && high > 5) return Optional.empty();
        List<Contact> contacts = new ArrayList<>();
        for (int first = 0; first < 6; first++) {
            int fret = frets.get(first);
            if (fret <= 0) continue;
            int covered = 0;
            for (int last = first; last < 6; last++) {
                int value = frets.get(last);
                // A finger cannot barre across a sounding open string or a lower fret.
                if (value < fret) break;
                if (value == fret) covered |= 1 << last;
                if (value == fret && (fret == low || last - first <= 2))
                    contacts.add(new Contact(fret, first, last, covered));
            }
        }
        Search search = new Search(frets, contacts, mask, low);
        search.visit(0, new ArrayList<>());
        return Optional.ofNullable(search.best);
    }

    private static double fretDistance(int low, int high) {
        return 648 * (Math.pow(2, -(low - .5) / 12.0) - Math.pow(2, -(high - .5) / 12.0));
    }

    private static final class Search {
        private final List<Integer> frets;
        private final List<Contact> contacts;
        private final int fullMask;
        private final int low;
        private Plan best;
        Search(List<Integer> frets, List<Contact> contacts, int fullMask, int low) {
            this.frets = frets; this.contacts = contacts; this.fullMask = fullMask; this.low = low;
        }
        void visit(int covered, List<Contact> chosen) {
            if (covered == fullMask) { accept(chosen); return; }
            if (chosen.size() == 4) return;
            int first = Integer.numberOfTrailingZeros(fullMask & ~covered);
            for (Contact contact : contacts) {
                if ((contact.mask() & (1 << first)) == 0 || (contact.mask() & covered) != 0) continue;
                chosen.add(contact);
                visit(covered | contact.mask(), chosen);
                chosen.remove(chosen.size() - 1);
            }
        }
        void accept(List<Contact> chosen) {
            List<Contact> ordered = chosen.stream().sorted(Comparator.comparingInt(Contact::fret)
                    .thenComparingInt(Contact::first)).toList();
            assign(ordered,new int[ordered.size()],0,1);
        }
        void assign(List<Contact> ordered,int[] digits,int index,int minimum) {
            if (index == ordered.size()) { acceptAssignment(ordered,digits); return; }
            for (int finger = minimum; finger <= 4-(ordered.size()-index-1); finger++) {
                boolean reachable = true;
                for (int before = 0; before < index; before++) {
                    int fretGap = ordered.get(index).fret()-ordered.get(before).fret();
                    int fingerGap = finger-digits[before];
                    if (fretGap > fingerGap+(low >= 5 ? 1 : 0)) { reachable = false; break; }
                }
                if (!reachable) continue;
                digits[index] = finger;
                assign(ordered,digits,index+1,finger+1);
            }
        }
        void acceptAssignment(List<Contact> ordered,int[] digits) {
            int[] fingers = new int[6];
            List<Barre> barres = new ArrayList<>();
            double effort = ordered.size() * 3.0;
            for (int i = 0; i < ordered.size(); i++) {
                Contact contact = ordered.get(i);
                int finger = digits[i];
                // Prefer an index-to-ring/pinky reach over stretching adjacent fingers.
                effort += .15*Math.abs((contact.fret()-low)-(finger-1));
                for (int string = contact.first(); string <= contact.last(); string++)
                    if ((contact.mask() & (1 << string)) != 0) fingers[string] = finger;
                if (contact.barre()) {
                    barres.add(new Barre(finger, contact.fret(), contact.first(), contact.last()));
                    effort += (contact.fret() == low ? 2 : 5) + .35 * (contact.last() - contact.first());
                }
                if (i > 0) {
                    Contact before = ordered.get(i - 1);
                    // Adjacent fingers at the same fret across far-apart strings are uncomfortable.
                    if (before.fret() == contact.fret()) effort += .5 * Math.abs(contact.first() - before.last());
                }
            }
            if (best == null || effort < best.effort()) {
                List<Integer> assignment = java.util.Arrays.stream(fingers).boxed().toList();
                best = new Plan(assignment, barres, ordered.size(), effort);
            }
        }
    }
}
