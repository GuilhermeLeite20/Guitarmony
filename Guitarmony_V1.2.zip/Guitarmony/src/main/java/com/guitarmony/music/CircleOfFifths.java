package com.guitarmony.music;

import java.util.List;

/** Twelve pitch classes ordered by ascending perfect fifth, with relative minors. */
public final class CircleOfFifths {
    public record Key(int index, String major, String relativeMinor, String signature) {
        public int pitch() { return Notes.pitch(major); }
        public String relativeMinorRoot() { return relativeMinor.substring(0, relativeMinor.length() - 1); }
        @Override public String toString() { return major + " · " + relativeMinor; }
    }

    private static final List<Key> KEYS = List.of(
            new Key(0, "C", "Am", "Sem acidentes"),
            new Key(1, "G", "Em", "1 sustenido"),
            new Key(2, "D", "Bm", "2 sustenidos"),
            new Key(3, "A", "F#m", "3 sustenidos"),
            new Key(4, "E", "C#m", "4 sustenidos"),
            new Key(5, "B", "G#m", "5 sustenidos"),
            new Key(6, "F#", "D#m", "6 sustenidos · ou 6 bemóis em Gb"),
            new Key(7, "Db", "Bbm", "5 bemóis"),
            new Key(8, "Ab", "Fm", "4 bemóis"),
            new Key(9, "Eb", "Cm", "3 bemóis"),
            new Key(10, "Bb", "Gm", "2 bemóis"),
            new Key(11, "F", "Dm", "1 bemol"));

    private CircleOfFifths() {}
    public static List<Key> keys() { return KEYS; }
    public static Key at(int index) { return KEYS.get(Math.floorMod(index, 12)); }
    public static Key forPitch(int pitch) {
        int normalized = Math.floorMod(pitch, 12);
        return KEYS.stream().filter(key -> key.pitch() == normalized).findFirst().orElseThrow();
    }
    public static Key next(String major) { return at(forPitch(Notes.pitch(major)).index() + 1); }
    public static Key previous(String major) { return at(forPitch(Notes.pitch(major)).index() - 1); }
}
