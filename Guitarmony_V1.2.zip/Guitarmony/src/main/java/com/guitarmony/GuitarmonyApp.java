package com.guitarmony;

import com.guitarmony.ui.WorkspacePanel;
import com.guitarmony.ui.Assets;
import javax.swing.*;
import java.awt.*;

/** Native, offline desktop entry point. No audio threads or background services. */
public final class GuitarmonyApp {
    private GuitarmonyApp() {}

    public static void main(String[] args) {
        if (GraphicsEnvironment.isHeadless()) {
            System.err.println("O Guitarmony precisa de um ambiente gráfico. Abra no IntelliJ e execute GuitarmonyApp, ou use java -jar dist/Guitarmony.jar no seu computador.");
            return;
        }
        SwingUtilities.invokeLater(() -> {
            installLookAndFeel();
            JFrame frame = new JFrame("Guitarmony");
            frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            frame.setIconImages(java.util.List.of(Assets.icon(16).getImage(),Assets.icon(32).getImage(),Assets.icon(64).getImage(),Assets.icon(256).getImage()));
            frame.setContentPane(new WorkspacePanel());
            frame.setMinimumSize(new Dimension(1100, 720));
            Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
            frame.setSize(Math.min(1800, screen.width - 48), Math.min(1160, screen.height - 60));
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }

    public static void installLookAndFeel() {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) { /* Swing's bundled fallback remains usable. */ }
        var readableFont = new javax.swing.plaf.FontUIResource(Font.SANS_SERIF, Font.PLAIN, 15);
        UIManager.put("defaultFont", readableFont);
        for (String component : new String[]{"Label", "Button", "ComboBox", "CheckBox", "RadioButton", "List", "Table", "TableHeader", "TextArea", "TextField", "Spinner", "OptionPane", "ToolTip"}) {
            UIManager.put(component + ".font", readableFont);
        }
        UIManager.put("nimbusBase", new Color(99, 96, 90));
        UIManager.put("nimbusFocus", new Color(237, 174, 34));
        UIManager.put("control", new Color(237, 234, 228));
        UIManager.put("nimbusSelectionBackground", new Color(245, 205, 103));
        UIManager.put("nimbusSelectedText", new Color(29,31,34));
        UIManager.put("text", new Color(29, 31, 34));
        UIManager.put("ComboBox.contentMargins", new Insets(5, 9, 5, 9));
        ToolTipManager.sharedInstance().setInitialDelay(220);
        ToolTipManager.sharedInstance().setDismissDelay(12000);
    }
}
