package com.guitarmony.ui;

import com.guitarmony.fretboard.*;
import com.guitarmony.music.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** One source of selection state. Changes replace the active study immediately. */
public final class WorkspacePanel extends JPanel {
    private final JComboBox<String> root = new JComboBox<>(Notes.displayRoots().toArray(String[]::new));
    private final JComboBox<Formula> formula = new JComboBox<>();
    private final JComboBox<ViewMode> view = new JComboBox<>(ViewMode.values());
    private final JSpinner anchor = new JSpinner(new SpinnerNumberModel(0,0,12,1));
    private final JComboBox<String> box = new JComboBox<>();
    private final JComboBox<String> tuningPreset = new JComboBox<>(Tuning.presets().keySet().toArray(String[]::new));
    private final JCheckBox darkWood = check("Escala realista",true);
    private final JCheckBox intervals = check("Ver intervalos",false);
    private final JCheckBox allNotes = check("Notas de fundo",true);
    private final JCheckBox flats = check("Preferir bemóis",false);
    private final JCheckBox sevenths = check("Tétrades",true);
    private final JCheckBox wholeField = check("Mostrar os 7 acordes",false);
    private final JCheckBox grip = check("Voicing tocável",false);
    private final JComboBox<HarmonicChord> chord = new JComboBox<>();
    private final JComboBox<Voicing> voicing = new JComboBox<>();
    private final JComboBox<String> progressionPreset = new JComboBox<>(new String[]{"Progressões sugeridas…","I · IV · V","II · V · I","I · V · VI · IV"});
    private final FretboardPanel board = new FretboardPanel();
    private final ChordDiagramPanel chordDiagram = new ChordDiagramPanel();
    private final JLabel studyTitle = Style.text("",25,true);
    private final JLabel studySubtitle = Style.muted("");
    private final JLabel tuningLabel = Style.muted("");
    private final JLabel status = Style.muted("Passe o mouse sobre uma nota para explorar.");
    private final JTextArea explanation = new JTextArea();
    private final JPanel noteChips = Style.row(7);
    private final JPanel legend = Style.column();
    private final JPanel chordCards = Style.row(8);
    private final JPanel progressionRow = Style.row(6);
    private final JPanel harmonyControls = Style.column();
    private final JPanel layersPanel = Style.column();
    private final JPanel tabs = Style.row(6);
    private final List<JButton> tabButtons = new ArrayList<>();
    private final List<Study> pinned = new ArrayList<>();
    private final Deque<HarmonicChord> progression = new ArrayDeque<>();
    private List<HarmonicChord> harmonized = List.of();
    private List<Voicing> voicings = List.of();
    private List<Layer> currentLayers = List.of();
    private Tuning tuning = Tuning.standard();
    private Family family = Family.MODES;
    private boolean harmonyTab;
    private boolean fieldsTab;
    private boolean circleTab;
    private final JComboBox<String> startString = new JComboBox<>(new String[]{"6ª · Mi grave", "5ª · Lá", "4ª · Ré", "3ª · Sol", "2ª · Si", "1ª · Mi aguda"});
    private final JPanel featurePanel = Style.column();
    private final JPanel visualTips = Style.column();
    private final JPanel advicePanel = Style.column();
    private final JComboBox<String> cycleDirection = new JComboBox<>(new String[]{"Ciclo das quintas", "Ciclo das quartas"});
    private JPanel formulaField;
    private JPanel viewField;
    private JPanel settingsPanel;
    private JDialog settingsDialog;
    private boolean updating;
    private boolean cleared;
    private boolean progressionDisplay;
    private final JButton pin = Style.button("+ Sobrepor seleção",false);
    private final JButton queue = Style.button("+ Na progressão",false);
    private final JButton sequenceChords = Style.button("Ver sequência",false);
    private JScrollPane page;

    private record Study(String root,Formula formula,ViewMode view,int anchor,int box,int startString) {}

    public WorkspacePanel() {
        super(new BorderLayout());
        setBackground(Style.BG);
        Style.name(this,"Área de estudo Guitarmony");
        setBorder(new EmptyBorder(0,14,8,14));
        add(buildHeader(),BorderLayout.NORTH);
        JPanel content = new StudyPage();
        content.setLayout(new BoxLayout(content,BoxLayout.Y_AXIS));content.setOpaque(false);
        
        content.add(buildSelection()); content.add(Box.createVerticalStrut(10));
        featurePanel.setAlignmentX(LEFT_ALIGNMENT);featurePanel.setVisible(false);content.add(featurePanel);
        content.add(buildBoard()); content.add(Box.createVerticalStrut(10));
        content.add(buildBottom());content.add(Box.createVerticalStrut(12));
        advicePanel.setAlignmentX(LEFT_ALIGNMENT);advicePanel.setVisible(false);content.add(advicePanel);
        settingsPanel=buildSettings();settingsPanel.setVisible(false);content.add(settingsPanel);
        page = new JScrollPane(content);
        page.setBorder(null); page.setOpaque(false);page.getViewport().setOpaque(false);
        page.getVerticalScrollBar().setUnitIncrement(22);
        page.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        add(page,BorderLayout.CENTER);
        JPanel footer=Style.row(12);footer.setBorder(new EmptyBorder(6,2,0,2));
        footer.add(new JLabel(Assets.logo(112,42)));status.setForeground(new Color(235,232,223));footer.add(status);
        add(footer,BorderLayout.SOUTH);
        configureListeners();
        root.setSelectedItem("E");
        changeTab(Family.MODES,false);
        bindKeys();
    }

    @Override protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g=(Graphics2D)graphics.create();
        g.setPaint(new GradientPaint(0,0,new Color(49,50,51),getWidth(),getHeight(),new Color(104,105,105)));
        g.fillRect(0,0,getWidth(),getHeight());
        g.setPaint(new RadialGradientPaint(new Point(getWidth()/3,getHeight()/2),Math.max(1,getWidth()/2),
                new float[]{0f,1f},new Color[]{new Color(190,188,182,58),new Color(74,75,76,0)}));
        g.fillRect(0,0,getWidth(),getHeight());g.dispose();
    }

    private JPanel buildHeader() {
        JPanel header=new JPanel(new BorderLayout(14,0));header.setOpaque(false);
        header.setBorder(new EmptyBorder(6,2,9,2));
        JLabel brand=new JLabel(Assets.logo(156,60));brand.setToolTipText("Guitarmony");header.add(brand,BorderLayout.WEST);
        header.add(buildTabs(),BorderLayout.CENTER);
        JPanel right=Style.row(5);
        JButton help=tabButton("?  Ajuda");Style.name(help,"Ajuda");help.addActionListener(e->showHelp());
        JButton settings=tabButton("");settings.setIcon(new GearIcon());settings.setBorder(new EmptyBorder(8,8,8,8));settings.setPreferredSize(new Dimension(40,40));
        settings.setForeground(Style.ACCENT);settings.setToolTipText("Configurações");Style.name(settings,"Configurações");
        settings.addActionListener(e->showSettings());right.add(help);right.add(settings);header.add(right,BorderLayout.EAST);
        return header;
    }

    private JPanel buildTabs() {
        for(Family f:new Family[]{Family.MODES,Family.PENTATONICS,Family.BLUES,Family.ARPEGGIOS,Family.SCALES}) {
            JButton button=tabButton(f.toString());Style.name(button,"Aba "+f);
            button.addActionListener(e->changeTab(f,false));tabs.add(button);tabButtons.add(button);
        }
        JButton chords=tabButton("Acordes");Style.name(chords,"Aba Acordes");
        chords.addActionListener(e->changeSpecialTab(0));tabs.add(chords);tabButtons.add(chords);
        JButton fields=tabButton("Campos");Style.name(fields,"Aba Campos");
        fields.addActionListener(e->changeSpecialTab(1));tabs.add(fields);tabButtons.add(fields);
        JButton circle=tabButton("Armadura de Clave");Style.name(circle,"Aba Armadura de Clave");
        circle.addActionListener(e->changeSpecialTab(2));tabs.add(circle);tabButtons.add(circle);
        tabs.setAlignmentX(LEFT_ALIGNMENT);return tabs;
    }

    private JButton tabButton(String label) {
        JButton button=new JButton(label) {
            @Override protected void paintComponent(Graphics graphics) {
                Graphics2D g=(Graphics2D)graphics.create();
                if(getModel().isRollover()){g.setColor(new Color(255,255,255,22));g.fillRoundRect(0,0,getWidth(),getHeight(),8,8);}
                if(Boolean.TRUE.equals(getClientProperty("active"))){g.setColor(Style.ACCENT);g.fillRoundRect(7,getHeight()-4,getWidth()-14,3,3,3);}
                g.dispose();super.paintComponent(graphics);
            }
        };
        button.setOpaque(false);button.setContentAreaFilled(false);button.setBorder(new EmptyBorder(16,9,13,9));
        button.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,15));button.setForeground(new Color(238,237,231));
        button.setFocusPainted(false);button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        Style.animate(button);return button;
    }

    private JPanel buildSelection() {
        JPanel card=Style.card(new BorderLayout(10,12)); card.setAlignmentX(LEFT_ALIGNMENT);Style.name(card,"Seleção de estudo");
        JPanel controls=Style.row(12);
        controls.add(field("TÔNICA / TOM",root,120));
        formulaField=field("O QUE ESTUDAR",formula,310);Style.name(formulaField,"Campo O que estudar");controls.add(formulaField);
        viewField=field("VISUALIZAÇÃO",view,240);Style.name(viewField,"Campo Visualização");controls.add(viewField);
        JPanel actions=Style.row(7);actions.setBorder(new EmptyBorder(19,0,0,0));
        actions.add(pin);JButton clear=Style.button("Limpar",false);Style.name(clear,"Limpar");
        clear.addActionListener(e->clearStudy());actions.add(clear);controls.add(actions);
        card.add(controls,BorderLayout.NORTH);
        harmonyControls.add(buildHarmonyControls());
        card.add(harmonyControls,BorderLayout.CENTER);
        Style.name(root,"Tônica");Style.name(formula,"Fórmula");Style.name(view,"Visualização");
        Style.name(anchor,"Casa inicial");Style.name(box,"Desenho");Style.name(pin,"Sobrepor seleção");
        return card;
    }

    private JPanel buildHarmonyControls() {
        JPanel p=Style.column();JPanel row=Style.row(10);
        chord.setRenderer(new DefaultListCellRenderer(){
            @Override public Component getListCellRendererComponent(JList<?> list,Object value,int index,boolean selected,boolean focus) {
                super.getListCellRendererComponent(list,value,index,selected,focus);
                if(value instanceof HarmonicChord c)setText(c.roman()+"   ·   "+c.name()); return this;
            }
        });
        voicing.setRenderer(new DefaultListCellRenderer(){
            @Override public Component getListCellRendererComponent(JList<?> list,Object value,int index,boolean selected,boolean focus) {
                super.getListCellRendererComponent(list,value,index,selected,focus);
                if(value instanceof Voicing v)setText(v.label()); return this;
            }
        });
        chord.setPreferredSize(new Dimension(210,42));voicing.setPreferredSize(new Dimension(460,42));
        row.add(field("ACORDE",chord,210));row.add(sevenths);row.add(grip);p.add(row);
        JPanel shape=Style.row(8);shape.add(field("FORMA PRIORIZADA PELO CONFORTO",voicing,460));shape.add(queue);p.add(shape);
        JPanel guidance=Style.row(10);guidance.add(wholeField);guidance.add(Style.muted("X = abafar · 0 = corda solta · casas da 6ª para a 1ª"));p.add(guidance);
        p.add(Box.createVerticalStrut(10));
        p.add(chordCards);p.add(Box.createVerticalStrut(8));
        JPanel progressionControls=Style.row(8);
        progressionPreset.setPreferredSize(new Dimension(195,32));
        progressionControls.add(Style.muted("SUA PROGRESSÃO"));progressionControls.add(progressionPreset);
        progressionControls.add(sequenceChords);
        JButton undo=Style.button("Remover último",false);undo.addActionListener(e->{
            progression.pollLast();if(progression.isEmpty())progressionDisplay=false;
            render();refreshProgression();
        });progressionControls.add(undo);
        p.add(progressionControls);p.add(Box.createVerticalStrut(8));p.add(progressionRow);
        Style.name(chord,"Acorde do campo");Style.name(wholeField,"Mostrar campo completo");
        Style.name(grip,"Voicing tocável");Style.name(voicing,"Forma do acorde");
        Style.name(progressionPreset,"Progressão sugerida");Style.name(queue,"Adicionar acorde à progressão");
        Style.name(sequenceChords,"Visualizar progressão");
        JPanel shell=new JPanel(new BorderLayout(14,0));shell.setOpaque(false);shell.add(p,BorderLayout.CENTER);
        chordDiagram.setVisible(false);shell.add(chordDiagram,BorderLayout.EAST);return shell;
    }

    private JPanel buildBoard() {
        JPanel card=Style.card(new BorderLayout(0,10));card.setAlignmentX(LEFT_ALIGNMENT);Style.name(card,"Cartão do braço");
        JPanel heading=Style.row(28);
        JPanel title=new JPanel(new BorderLayout(0,6));title.setOpaque(false);title.add(studyTitle,BorderLayout.NORTH);title.add(studySubtitle,BorderLayout.SOUTH);
        heading.add(title);
        JPanel actions=Style.row(8);actions.add(intervals);actions.add(allNotes);
        heading.add(actions);
        card.add(heading,BorderLayout.NORTH);
        JScrollPane neck=new JScrollPane(board);neck.setBorder(null);neck.getViewport().setBackground(Color.WHITE);
        neck.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        neck.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
        neck.setPreferredSize(new Dimension(1200,FretboardPanel.PREFERRED_HEIGHT));
        neck.setMinimumSize(new Dimension(500,FretboardPanel.MIN_READABLE_HEIGHT));Style.name(neck,"Visualizador do braço");neck.getHorizontalScrollBar().setUnitIncrement(55);
        card.add(neck,BorderLayout.CENTER);
        JPanel footer=Style.column();footer.add(noteChips);footer.add(Box.createVerticalStrut(12));
        card.add(footer,BorderLayout.SOUTH);
        board.setCellListener(cell->{
            String note=tuning.nameAt(cell.stringIndex(),cell.fret(),flats.isSelected());
            StringBuilder s=new StringBuilder("Corda ").append(6-cell.stringIndex()).append(" · casa ").append(cell.fret()).append(" · ").append(note);
            for(Layer layer:currentLayers) if(layer.cells().contains(cell)) {
                int idx=layer.formula().intervals().indexOf(Math.floorMod(tuning.pitchAt(cell.stringIndex(),cell.fret())-Notes.pitch(layer.root()),12));
                s.append("   |   ").append(layer.label()).append(": ").append(layer.formula().degrees().get(idx));
            }
            status.setText(s.toString());
        });
        return card;
    }

    private JPanel buildBottom() {
        JPanel bottom=new JPanel(new GridLayout(1,2,14,0));bottom.setOpaque(false);bottom.setAlignmentX(LEFT_ALIGNMENT);
        JPanel left=Style.card(new BorderLayout(0,12));
        left.add(sectionTitle("▱", "Camadas & desenhos"),BorderLayout.NORTH);
        JPanel layerContent=Style.column();layerContent.add(layersPanel);layerContent.add(legend);
        JScrollPane scroll=new JScrollPane(layerContent);scroll.setBorder(null);scroll.setViewportBorder(null);scroll.setOpaque(false);scroll.getViewport().setOpaque(false);
        scroll.setPreferredSize(new Dimension(460,140));scroll.getVerticalScrollBar().setUnitIncrement(18);
        left.add(scroll,BorderLayout.CENTER);bottom.add(left);
        JPanel right=Style.card(new BorderLayout(0,12));right.add(sectionTitle("ⓘ", "Entenda o que está vendo"),BorderLayout.NORTH);
        explanation.setEditable(false);explanation.setLineWrap(true);explanation.setWrapStyleWord(true);
        explanation.setFocusable(false);
        ((javax.swing.text.DefaultCaret)explanation.getCaret()).setUpdatePolicy(javax.swing.text.DefaultCaret.NEVER_UPDATE);
        explanation.setOpaque(false);explanation.setForeground(Style.MUTED);explanation.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,13));
        explanation.setRows(6);right.add(visualTips,BorderLayout.CENTER);bottom.add(right);
        return bottom;
    }

    private static JPanel field(String title,JComponent input,int width) {
        JPanel p=Style.column();p.setAlignmentX(LEFT_ALIGNMENT);p.add(Style.muted(title));p.add(Box.createVerticalStrut(5));
        input.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,16));
        input.setPreferredSize(new Dimension(width,42));input.setMaximumSize(new Dimension(width,42));
        input.setAlignmentX(LEFT_ALIGNMENT);p.add(input);return p;
    }
    private static JCheckBox check(String title,boolean selected) {
        JCheckBox c=new JCheckBox(title,selected);c.setOpaque(false);c.setForeground(Style.MUTED);
        c.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,15));return c;
    }

    private void configureListeners() {
        root.addActionListener(e->selectionChanged(true));
        startString.addActionListener(e->{if(!updating)render();});
        cycleDirection.addActionListener(e->{if(circleTab&&!updating){refreshFeature();render();}});
        Style.name(cycleDirection,"Sentido do ciclo");cycleDirection.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,17));
        formula.addActionListener(e->{if(!updating){configureBoxes();selectionChanged(true);}});
        view.addActionListener(e->selectionChanged(false));
        anchor.addChangeListener(e->selectionChanged(false));box.addActionListener(e->selectionChanged(false));
        chord.addActionListener(e->{if(!updating){cleared=false;progressionDisplay=false;updateVoicings();render();}});
        voicing.addActionListener(e->{if(!updating)render();});
        sevenths.addActionListener(e->selectionChanged(true));
        wholeField.addActionListener(e->{chordCards.setVisible(wholeField.isSelected());refreshChordCards();});
        grip.addActionListener(e->{updateVoicings();render();});
        for(JCheckBox toggle:new JCheckBox[]{darkWood,intervals,allNotes,flats})toggle.addActionListener(e->{
            if(toggle==flats&&harmonyTab)selectionChanged(true);else render();
        });
        tuningPreset.addActionListener(e->{if(!updating){
            Tuning preset=Tuning.presets().get(tuningPreset.getSelectedItem());if(preset!=null){tuning=preset;tuningChanged();}
        }});
        pin.addActionListener(e->{
            if(cleared)return;
            if(pinned.size()>=6){status.setText("Até 6 seleções fixadas. Remova uma camada antes de adicionar outra.");return;}
            Study selection=study(); if(!pinned.contains(selection))pinned.add(selection);
            render();status.setText("Seleção fixada. Agora escolha outro modo, tom ou aba para comparar.");
        });
        queue.addActionListener(e->{HarmonicChord c=(HarmonicChord)chord.getSelectedItem();if(c!=null){
            if(progression.size()==16)progression.removeFirst();progression.addLast(c);refreshProgression();
            if(progressionDisplay)render();
        }});
        sequenceChords.addActionListener(e->{cleared=false;progressionDisplay=!progressionDisplay;render();});
        progressionPreset.addActionListener(e->{if(!updating&&progressionPreset.getSelectedIndex()>0){
            int[] indices=switch(progressionPreset.getSelectedIndex()){case 1->new int[]{0,3,4};case 2->new int[]{1,4,0};default->new int[]{0,4,5,3};};
            progression.clear();for(int i:indices)progression.addLast(harmonized.get(i));
            progressionDisplay=true;cleared=false;refreshProgression();render();
        }});
    }

    private void changeTab(Family next,boolean chordsTab) {
        fieldsTab=false;circleTab=false;featurePanel.removeAll();featurePanel.setVisible(false);formula.setEnabled(true);formulaField.setVisible(true);viewField.setVisible(true);pin.setVisible(true);
        updating=true; family=next;harmonyTab=chordsTab;progressionDisplay=false;cleared=false;
        formula.setModel(new DefaultComboBoxModel<>(Catalog.forFamily(next).toArray(Formula[]::new)));
        harmonyControls.setVisible(chordsTab);view.setEnabled(!chordsTab);box.setEnabled(!chordsTab);
        pin.setEnabled(!chordsTab);
        int selected=chordsTab?5:switch(next){case MODES->0;case PENTATONICS->1;case BLUES->2;case ARPEGGIOS->3;case SCALES->4;};
        for(int i=0;i<tabButtons.size();i++){
            tabButtons.get(i).putClientProperty("active",i==selected);
            tabButtons.get(i).setFont(new Font(Font.SANS_SERIF,i==selected?Font.BOLD:Font.PLAIN,14));
            tabButtons.get(i).setForeground(i==selected?Color.WHITE:new Color(225,223,217));
        }
        updating=false;configureBoxes();selectionChanged(true);revalidate();
        if(page!=null)SwingUtilities.invokeLater(()->page.getViewport().setViewPosition(new Point(0,0)));
    }

    private void configureBoxes() {
        boolean previous=updating;updating=true;
        Formula f=(Formula)formula.getSelectedItem();
        if(f!=null&&(f.family()==Family.PENTATONICS||f.family()==Family.BLUES))
            box.setModel(new DefaultComboBoxModel<>(new String[]{"Desenho 1","Desenho 2","Desenho 3","Desenho 4","Desenho 5"}));
        else box.setModel(new DefaultComboBoxModel<>(new String[]{"Tônica na 6ª"}));
        updating=previous;
    }

    private void selectionChanged(boolean rebuildHarmony) {
        if(updating||formula.getSelectedItem()==null)return;
        cleared=false;progressionDisplay=false;
        if(harmonyTab&&rebuildHarmony) {
            updating=true;int selected=Math.max(0,chord.getSelectedIndex());
            harmonized=Harmony.displayHarmonize((String)root.getSelectedItem(),(Formula)formula.getSelectedItem(),sevenths.isSelected(),flats.isSelected());
            chord.setModel(new DefaultComboBoxModel<>(harmonized.toArray(HarmonicChord[]::new)));
            chord.setSelectedIndex(Math.min(selected,6));
            // A new key/scale replaces every chord from the old harmonic context.
            progression.clear();progressionPreset.setSelectedIndex(0);
            updating=false;refreshChordCards();refreshProgression();
        }
        if(harmonyTab)updateVoicings();render();
        if(fieldsTab||circleTab)refreshFeature();
    }

    private Study study() {
        return new Study((String)root.getSelectedItem(),(Formula)formula.getSelectedItem(),
                (ViewMode)view.getSelectedItem(),(Integer)anchor.getValue(),Math.max(0,box.getSelectedIndex()),startString.getSelectedIndex());
    }

    private List<Layer> layersFor(Study study,int colorIndex) {
        List<Layer> result=new ArrayList<>();int pitch=Notes.pitch(study.root());
        if(study.view()==ViewMode.ALL_NOTES) {
            result.add(new Layer(study.root()+" "+study.formula().name(),study.root(),study.formula(),
                    ShapeEngine.allNotes(study.formula(),pitch,tuning),Style.COLORS[colorIndex%7]));
        } else if(study.view()==ViewMode.ONE_SHAPE) {
            Position position;
            if(study.formula().family()==Family.PENTATONICS||study.formula().family()==Family.BLUES) {
                position=ShapeEngine.boxShape(study.formula(),pitch,tuning,study.anchor(),study.box(),study.startString());
            } else position=ShapeEngine.shape(study.formula(),pitch,tuning,study.anchor(),study.startString());
            String boxName=study.formula().family()==Family.PENTATONICS||study.formula().family()==Family.BLUES?
                    " · desenho "+(study.box()+1)+(position.label().contains("oitava anterior")?" · oitava anterior":""):"";
            result.add(new Layer(study.root()+" "+study.formula().name()+boxName+" · casas "+position.startFret()+"–"+position.endFret(),
                    study.root(),study.formula(),position.cells(),Style.COLORS[colorIndex%7]));
        } else {
            List<Position> positions=ShapeEngine.sequence(study.formula(),pitch,tuning,study.anchor(),study.startString());
            for(int i=0;i<positions.size();i++){
                Position p=positions.get(i);
                String layerRoot=study.root();
                if(study.formula().family()==Family.MODES){
                    List<String> modeNames=Notes.display(study.root(),study.formula(),flats.isSelected());
                    layerRoot=modeNames.get(i%7);
                }
                String label=study.formula().family()==Family.MODES?
                        layerRoot+" "+p.formula().name()+(i>=7?" · oitava":""):p.label();
                result.add(new Layer(label,layerRoot,p.formula(),p.cells(),Style.COLORS[(colorIndex+i)%7]));
            }
        }
        return result;
    }

    private void render() {
        if(updating||formula.getSelectedItem()==null)return;
        Study current=study();List<Layer> result=new ArrayList<>();
        for(int i=0;i<pinned.size();i++)result.addAll(layersFor(pinned.get(i),i));
        List<Layer> active=new ArrayList<>();
        if(!cleared) {
            if(harmonyTab) {
                if(progressionDisplay) {
                    int i=0;for(HarmonicChord c:progression)active.add(chordLayer(c,i++));
                } else {
                    HarmonicChord c=(HarmonicChord)chord.getSelectedItem();if(c!=null){
                        if(grip.isSelected()&&voicing.getSelectedItem() instanceof Voicing v) {
                            Set<Cell> cells=new LinkedHashSet<>();for(int s=0;s<6;s++)if(v.frets().get(s)>=0)cells.add(new Cell(s,v.frets().get(s)));
                            active.add(new Layer(c.name()+" · "+v.label(),c.root(),c.formula(),cells,Style.COLORS[0]));
                        } else active.add(chordLayer(c,0));
                    }
                }
            } else active.addAll(layersFor(current,pinned.size()));
            for(Layer layer:active)if(result.stream().noneMatch(p->p.cells().equals(layer.cells())&&p.root().equals(layer.root())&&p.formula().equals(layer.formula())))result.add(layer);
        }
        currentLayers=List.copyOf(result);
        board.setData(tuning,currentLayers,darkWood.isSelected(),intervals.isSelected(),flats.isSelected(),allNotes.isSelected());
        tuningLabel.setText(tuning.summary()+"  ·  6ª → 1ª");
        studyTitle.setText(cleared?"Braço livre para explorar":harmonyTab?
                (progressionDisplay?"Sua progressão em "+current.root():chord.getSelectedItem() instanceof HarmonicChord c?c.name():"Campo harmônico"):
                current.root()+" "+current.formula().name());
        String subtitle=harmonyTab?(grip.isSelected()&&!progressionDisplay?"Forma priorizada pelo conforto · X = abafar · 0 = corda solta":"Notas do acorde · não é uma posição para tocar todas as bolinhas juntas"):
                current.view()==ViewMode.ALL_NOTES?"Todas as ocorrências das notas escolhidas · casas 0 a 24":
                current.view()==ViewMode.ONE_SHAPE?"Um desenho de referência · calculado para a afinação e a região escolhidas":
                current.formula().family()==Family.MODES?"Modos relativos do mesmo campo · desenhos diferentes · repetição na oitava":"Desenhos da mesma escala · cores por posição · repetição na oitava";
        if(cleared)subtitle="Escolha um tom ou uma fórmula para recomeçar. Afinação e preferências foram mantidas.";
        studySubtitle.setText(subtitle);updateChips(current,active);updateLayersLegend();updateExplanation(current);updateImprovisation(current);
        boolean showDiagram=harmonyTab&&!fieldsTab&&!circleTab&&grip.isSelected()&&voicing.getSelectedItem() instanceof Voicing;
        chordDiagram.setVisible(showDiagram);
        if(showDiagram&&chord.getSelectedItem() instanceof HarmonicChord selected)chordDiagram.setChord(selected,(Voicing)voicing.getSelectedItem(),tuning,flats.isSelected());
        alignColumns(this);
        boolean positional=!harmonyTab&&current.view()!=ViewMode.ALL_NOTES;
        anchor.setEnabled(positional||(harmonyTab&&grip.isSelected()));
        box.setEnabled(positional&&current.view()==ViewMode.ONE_SHAPE&&box.getItemCount()>1);
        voicing.setEnabled(harmonyTab&&grip.isSelected()&&!progressionDisplay);
        sequenceChords.setText(progressionDisplay?"Ver acorde isolado":"Ver sequência");
        sequenceChords.setEnabled(!progression.isEmpty());queue.setEnabled(!cleared);
        revalidate();repaint();
    }

    private Layer chordLayer(HarmonicChord c,int index) {
        return new Layer(c.name(),c.root(),c.formula(),ShapeEngine.allNotes(c.formula(),Notes.pitch(c.root()),tuning),Style.COLORS[index%7]);
    }

    private void updateChips(Study current,List<Layer> active) {
        noteChips.removeAll();if(cleared){noteChips.add(Style.muted("Nenhuma seleção ativa."));return;}
        Formula f=current.formula();String r=current.root();
        if(harmonyTab&&chord.getSelectedItem() instanceof HarmonicChord c){f=c.formula();r=c.root();}
        List<String> names=Notes.display(r,f,flats.isSelected());
        for(int i=0;i<names.size();i++) {
            JLabel chip=Style.text(" "+names.get(i)+"   "+f.degrees().get(i)+" ",16,i==0);
            chip.setOpaque(true);chip.setBackground(i==0?new Color(18,130,73):new Color(233,231,224));chip.setForeground(i==0?Color.WHITE:Style.INK);
            chip.setBorder(new EmptyBorder(5,7,5,7));noteChips.add(chip);
        }
        noteChips.add(Style.muted("  T = tônica   ◇ = blue note   anéis = sobreposição"));
    }

    private void updateLayersLegend() {
        layersPanel.removeAll();legend.removeAll();
        for(int i=0;i<pinned.size();i++) {
            final int index=i;Study s=pinned.get(i);JPanel row=Style.row(8);
            JLabel title=Style.text("●  "+s.root()+" "+s.formula().name(),15,true);title.setForeground(Style.ACCENT);
            row.add(title);JButton remove=Style.button("Remover",false);remove.addActionListener(e->{pinned.remove(index);render();});row.add(remove);layersPanel.add(row);
        }
        if(currentLayers.isEmpty()){legend.add(Style.muted("As seleções aparecem aqui, com sua cor e região."));return;}
        for(Layer layer:currentLayers) {
            JPanel row=Style.row(8);JLabel dot=Style.text("●",18,true);dot.setForeground(layer.color().darker());row.add(dot);
            row.add(Style.text(layer.label()+"   ·   "+layer.cells().size()+" posições",15,false));legend.add(row);
        }
    }

    private void updateExplanation(Study current) {
        String extra;
        if(harmonyTab){
            extra="O campo é calculado empilhando terças da escala escolhida. Selecione um grau para ver só aquele acorde; abra os sete quando precisar. Adicione acordes à fila para montar sua progressão.\n\n"+
                    (grip.isSelected()?"As formas são priorizadas pelo conforto e preservam todas as notas do acorde. Inversões podem facilitar a mão; a nota mais grave é indicada na forma. X = abafar, 0 = corda solta. Confira a ergonomia na sua guitarra.":"No mapa, as bolinhas são alternativas para localizar os sons do acorde. Ative ‘Voicing tocável’ para ver uma posição de mão.");
            if(grip.isSelected()&&voicings.isEmpty())extra+="\nNenhum voicing completo encontrado nesta afinação/região. O mapa de notas continua disponível.";
        } else {
            extra=current.formula().description()+"\n\n"+switch(current.view()) {
                case ALL_NOTES->"Braço inteiro destaca todas as ocorrências. Mudar a tônica ou a fórmula substitui a seleção na hora. ‘Sobrepor seleção’ fixa o estudo atual para compará-lo com outra escolha.";
                case ONE_SHAPE->"Modos usam três notas por corda; pentas usam dois sons por corda, com cinco desenhos. No blues, a nota cromática é acrescentada ao box. Arpejos usam um mapa local de cinco casas, não um voicing.";
                case SEQUENCE->"Cada cor representa um desenho localizado. Nos modos, a tônica avança pelos graus do mesmo campo (E Jônio → F# Dórico → G# Frígio…). As cores se repetem na oitava. Os anéis mostram regiões que se cruzam.";
            };
            if(current.view()!=ViewMode.ALL_NOTES)extra+="\nDesenhos são recalculados pela afinação; partes abaixo da casa 0 ou acima da 24 são cortadas. Um box que começaria após a casa 24 retorna à oitava anterior. Afinações muito abertas podem exigir alongamentos.";
        }
        explanation.setText(extra);
        visualTips.removeAll();
        Formula selected=current.formula();
        String context=harmonyTab?"Terças empilhadas formam os acordes de cada grau.":selected.description();
        String structure=harmonyTab&&chord.getSelectedItem() instanceof HarmonicChord c?
                c.name()+"  ·  "+String.join(" – ",c.notes()):String.join(" – ",selected.degrees());
        String onBoard=cleared?"Escolha um tom e uma fórmula para destacar as notas.":harmonyTab?
                (grip.isSelected()?"Todas as notas do acorde preservadas. Formas priorizadas pelo conforto; inversões podem facilitar. X = abafar, 0 = corda solta.":"As notas são alternativas no braço. Use Voicing tocável para uma posição de mão."):
                current.view()==ViewMode.ALL_NOTES?"Veja as notas em todas as seis cordas. Verde indica a tônica.":
                "Comece pela "+startString.getSelectedItem()+". O desenho acompanha a afinação.";
        String practice=circleTab?(cycleDirection.getSelectedIndex()==0?"No sentido horário, C → G → D avança em quintas. Volte para percorrer quartas.":"No sentido horário, C → F → Bb avança em quartas. Volte para percorrer quintas."):fieldsTab?
                "Escolha um tom na tabela, toque os graus 1–4–5 e observe a qualidade dos acordes antes de voltar ao primeiro.":harmonyTab?
                "Monte uma progressão e compare as notas comuns entre os acordes.":"Toque devagar de tônica a tônica. Diga o nome de cada nota enquanto toca.";
        if(circleTab){
            int pitch=Notes.pitch(current.root());boolean preferFlats=current.root().contains("b");
            context=cycleDirection.getSelectedIndex()==0?"As armaduras se organizam em quintas no sentido horário; o caminho inverso percorre quartas.":"As armaduras se organizam em quartas no sentido horário; o caminho inverso percorre quintas.";
            structure=current.root()+" maior  ·  V: "+Notes.chromatic(pitch+7,preferFlats)+"  ·  IV: "+Notes.chromatic(pitch+5,preferFlats)+"  ·  relativo: "+Notes.chromatic(pitch+9,preferFlats)+"m";
            onBoard="O braço mostra a escala maior do tom selecionado no círculo. A tônica permanece verde.";
        }else if(fieldsTab){
            context=current.root()+" "+selected.name()+": cada acorde é formado por notas alternadas da escala (empilhamento de terças).";
            structure=harmonized.stream().map(c->c.roman()+": "+c.name()).collect(java.util.stream.Collectors.joining("  ·  "));
            onBoard=chord.getSelectedItem() instanceof HarmonicChord c?"Grau "+c.degree()+": "+c.name()+" = "+String.join(" – ",c.notes())+". A tabela completa reúne os 12 sons e suas grafias enarmônicas usuais.":"Clique em um acorde da tabela para visualizar suas notas.";
        }
        addTip("01",circleTab?"O ciclo":fieldsTab?"O campo":harmonyTab?"Harmonia":"O que é",context);
        addTip("02","Estrutura",structure);
        addTip("03","No braço",onBoard);
        addTip("04","Pratique",practice);
        visualTips.revalidate();visualTips.repaint();
    }

    private void updateVoicings() {
        if(!harmonyTab)return;
        boolean previous=updating;updating=true;int selected=Math.max(0,voicing.getSelectedIndex());
        HarmonicChord c=(HarmonicChord)chord.getSelectedItem();
        voicings=c==null||!grip.isSelected()?List.of():VoicingEngine.find(c.root(),c.formula(),tuning,(Integer)anchor.getValue());
        voicing.setModel(new DefaultComboBoxModel<>(voicings.toArray(Voicing[]::new)));
        if(!voicings.isEmpty())voicing.setSelectedIndex(Math.min(selected,voicings.size()-1));
        updating=previous;
    }

    private void refreshChordCards() {
        chordCards.removeAll();chordCards.setVisible(wholeField.isSelected());
        for(int i=0;i<harmonized.size();i++){
            int index=i;HarmonicChord c=harmonized.get(i);
            JButton button=Style.button(c.roman()+" · "+c.name(),false);
            button.setToolTipText(String.join(" · ",c.notes()));button.addActionListener(e->chord.setSelectedIndex(index));chordCards.add(button);
        }
        revalidate();repaint();
    }

    private void refreshProgression() {
        progressionRow.removeAll();int i=0;
        for(HarmonicChord c:progression){
            JLabel label=Style.text((++i)+". "+c.name()+"  "+(i<progression.size()?"→":""),13,true);progressionRow.add(label);
        }
        if(progression.isEmpty())progressionRow.add(Style.muted("Adicione acordes ou escolha uma sugestão. Até 16 passos, na ordem em que você escolheu."));
        sequenceChords.setEnabled(!progression.isEmpty());revalidate();repaint();
    }

    private void tuningChanged() {
        cleared=false;updateVoicings();render();status.setText("Afinação atualizada. Todas as posições foram recalculadas.");
    }
    private void shiftTuning(int semitones) {
        try{tuning=tuning.shift(semitones);markCustomTuning();tuningChanged();}
        catch(IllegalArgumentException e){status.setText("Limite de afinação atingido. Escolha outra afinação no menu.");}
    }
    private void markCustomTuning(){boolean previous=updating;updating=true;
        boolean present=false;for(int i=0;i<tuningPreset.getItemCount();i++)if("Personalizada".equals(tuningPreset.getItemAt(i)))present=true;
        if(!present)tuningPreset.addItem("Personalizada");tuningPreset.setSelectedItem("Personalizada");updating=previous;
    }

    private void editTuning() {
        JPanel form=Style.column();form.add(Style.muted("Cada clique altera 1 semitom. A ordem abaixo vai da 6ª para a 1ª corda."));
        for(int s=0;s<6;s++) {
            final int string=s;JPanel row=Style.row(10);JLabel note=Style.text(tuning.nameAt(s,0,false),17,true);
            row.add(Style.text("Corda "+(6-s),13,false));
            JButton down=Style.button("−",false),up=Style.button("+",false);
            down.addActionListener(e->{try{tuning=tuning.shiftString(string,-1);note.setText(tuning.nameAt(string,0,false));markCustomTuning();tuningChanged();}catch(IllegalArgumentException ex){status.setText("Limite de afinação atingido para esta corda.");}});
            up.addActionListener(e->{try{tuning=tuning.shiftString(string,1);note.setText(tuning.nameAt(string,0,false));markCustomTuning();tuningChanged();}catch(IllegalArgumentException ex){status.setText("Limite de afinação atingido para esta corda.");}});
            row.add(down);row.add(note);row.add(up);form.add(row);form.add(Box.createVerticalStrut(6));
        }
        JOptionPane.showMessageDialog(this,form,"Afinação por corda",JOptionPane.PLAIN_MESSAGE);
    }

    private void clearStudy() {
        pinned.clear();progression.clear();progressionDisplay=false;cleared=true;
        boolean previous=updating;updating=true;progressionPreset.setSelectedIndex(0);updating=previous;
        refreshProgression();render();status.setText("Seleção removida.");
    }

    private void bindKeys() {
        getInputMap(WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(KeyStroke.getKeyStroke(KeyEvent.VK_L,KeyEvent.CTRL_DOWN_MASK),"clear");
        getActionMap().put("clear",new AbstractAction(){@Override public void actionPerformed(java.awt.event.ActionEvent e){clearStudy();}});
    }
    private void showHelp() {
        JTextArea text=new JTextArea("COMECE PELO SOM QUE VOCÊ QUER ENTENDER\n\n1. Escolha uma matéria, a tônica e a fórmula. A seleção é atualizada imediatamente.\n\n2. Em Visualização, use Braço inteiro para localizar notas; Um desenho para praticar uma posição; Sequência para conectar regiões. Na engrenagem, escolha a corda de partida.\n\n3. A tônica aparece sempre em verde. O losango marca a blue note. Anéis coloridos mostram camadas sobrepostas. Passe o mouse ou clique em uma nota para inspecionar.\n\n4. Use Sobrepor seleção para comparar escalas e Limpar (Ctrl+L) para recomeçar.\n\n5. Acordes mostra notas, formas tocáveis e progressões. Campos reúne a tabela dos sete graus da escala escolhida. No Ciclo das quintas, clique em um tom e veja suas relações.\n\n6. Na engrenagem: escolha a afinação, ajuste cada corda, alterne o braço realista e escolha bemóis. Os botões −/+ 1 tom alteram a afinação em dois semitons; o tom do estudo permanece.\n\n7. Usamos nomes enarmônicos familiares para facilitar a leitura, preservando as alturas e os graus da fórmula.");
        text.setWrapStyleWord(true);text.setLineWrap(true);text.setEditable(false);text.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,14));text.setColumns(48);text.setMargin(new Insets(14,14,14,14));
        JScrollPane scroll=new JScrollPane(text);scroll.setPreferredSize(new Dimension(600,480));
        JOptionPane.showMessageDialog(this,scroll,"Ajuda · Guitarmony",JOptionPane.PLAIN_MESSAGE);
    }

    private JComponent sectionTitle(String glyph,String text) {
        JPanel panel=new JPanel(new BorderLayout(8,0));panel.setOpaque(false);
        JLabel icon=Style.text(glyph,21,true);icon.setForeground(Style.ACCENT);panel.add(icon,BorderLayout.WEST);
        panel.add(Style.text(text,19,true),BorderLayout.CENTER);
        panel.setBorder(javax.swing.BorderFactory.createMatteBorder(0,0,1,0,Style.ACCENT));return panel;
    }

    private void addTip(String number,String title,String body) {
        JPanel row=new JPanel(new BorderLayout(10,0));row.setOpaque(false);
        row.setBorder(new EmptyBorder(5,0,5,0));
        JLabel badge=Style.text(number,14,true);badge.setForeground(Style.ACCENT);row.add(badge,BorderLayout.WEST);
        JLabel description=new JLabel("<html><div style='width:300px'><b>"+html(title)+"</b>  ·  "+html(body)+"</div></html>");
        description.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,15));description.setForeground(Style.INK);
        row.add(description,BorderLayout.CENTER);visualTips.add(row);
    }

    private JPanel buildSettings() {
        JPanel panel=Style.card(new BorderLayout(0,12));Style.name(panel,"Painel de configurações");
        JPanel options=Style.column();
        options.add(sectionTitle("♪","Afinação"));options.add(Box.createVerticalStrut(10));
        tuningPreset.setPreferredSize(new Dimension(310,34));Style.name(tuningPreset,"Afinação");
        JPanel tuningRow=Style.row(8);tuningRow.add(tuningPreset);
        JButton minus=Style.button("− 1 tom",false),plus=Style.button("+ 1 tom",false);
        minus.addActionListener(e->shiftTuning(-2));plus.addActionListener(e->shiftTuning(2));
        Style.name(minus,"Descer afinação um tom");Style.name(plus,"Subir afinação um tom");
        tuningRow.add(minus);tuningRow.add(plus);options.add(tuningRow);
        JPanel perString=Style.row(8);JButton individual=Style.button("Por corda…",false);Style.name(individual,"Afinação por corda");
        individual.addActionListener(e->editTuning());perString.add(individual);perString.add(tuningLabel);options.add(perString);
        options.add(Box.createVerticalStrut(16));options.add(sectionTitle("◈","Visual e construção"));options.add(Box.createVerticalStrut(8));
        JPanel toggles=Style.row(12);toggles.add(darkWood);toggles.add(flats);options.add(toggles);
        Style.name(darkWood,"Escala realista");Style.name(flats,"Preferir bemóis");
        options.add(Box.createVerticalStrut(10));Style.name(startString,"Corda de partida");
        options.add(field("COMEÇAR O DESENHO PELA CORDA",startString,300));
        JLabel hint=new JLabel("<html><div style='width:540px'>A corda de partida vale para Um desenho e Sequência. As cordas mais graves ficam livres. No braço inteiro, todas as cordas continuam disponíveis.</div></html>");
        hint.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,15));hint.setForeground(Style.MUTED);
        options.add(Box.createVerticalStrut(9));options.add(hint);for(Component child:options.getComponents())if(child instanceof JComponent jc)jc.setAlignmentX(LEFT_ALIGNMENT);panel.add(options,BorderLayout.CENTER);return panel;
    }

    private void showSettings() {
        if(GraphicsEnvironment.isHeadless()){status.setText("Configurações disponíveis no aplicativo gráfico.");return;}
        if(settingsDialog==null){
            Window owner=SwingUtilities.getWindowAncestor(this);
            settingsDialog=new JDialog(owner,"Configurações",Dialog.ModalityType.APPLICATION_MODAL);
            settingsDialog.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
            JPanel shell=new JPanel(new BorderLayout());shell.setBackground(Style.BG);shell.setBorder(new EmptyBorder(8,8,8,8));
            settingsPanel.setVisible(true);shell.add(settingsPanel,BorderLayout.CENTER);
            JButton done=Style.button("Concluir",true);done.addActionListener(e->settingsDialog.setVisible(false));
            JPanel actions=Style.row(8);actions.add(done);shell.add(actions,BorderLayout.SOUTH);settingsDialog.setContentPane(shell);
            settingsDialog.setSize(760,540);settingsDialog.setMinimumSize(new Dimension(700,500));
        }
        settingsDialog.setLocationRelativeTo(SwingUtilities.getWindowAncestor(this));settingsDialog.setVisible(true);
    }

    private void changeSpecialTab(int index) {
        changeTab(Family.SCALES,true);fieldsTab=index==1;circleTab=index==2;
        harmonyControls.setVisible(index==0);
        for(int i=0;i<tabButtons.size();i++){boolean active=i==5+index;tabButtons.get(i).putClientProperty("active",active);tabButtons.get(i).setFont(new Font(Font.SANS_SERIF,active?Font.BOLD:Font.PLAIN,14));tabButtons.get(i).setForeground(active?Color.WHITE:new Color(225,223,217));}
        if(fieldsTab){updating=true;formula.setModel(new DefaultComboBoxModel<>(Harmony.fieldScales().toArray(Formula[]::new)));updating=false;selectionChanged(true);}
        if(circleTab){formulaField.setVisible(false);viewField.setVisible(false);pin.setVisible(false);harmonyTab=false;updating=true;formula.setModel(new DefaultComboBoxModel<>(new Formula[]{Catalog.byId("major")}));formula.setEnabled(false);view.setSelectedItem(ViewMode.ALL_NOTES);updating=false;selectionChanged(true);}
        refreshFeature();render();
    }

    private void refreshFeature() {
        featurePanel.removeAll();featurePanel.setVisible(fieldsTab||circleTab);
        if(fieldsTab){
            JPanel card=Style.card(new BorderLayout(0,10));card.setAlignmentX(LEFT_ALIGNMENT);
            card.add(sectionTitle("▦","Campo harmônico · "+root.getSelectedItem()+" "+formula.getSelectedItem()),BorderLayout.NORTH);
            JPanel grid=new JPanel(new GridLayout(1,7,7,0));grid.setOpaque(false);
            for(int i=0;i<harmonized.size();i++){
                HarmonicChord c=harmonized.get(i);final int degree=i;
                JButton button=Style.button("<html><center><b>"+c.roman()+"</b><br><span style='font-size:17px'>"+c.name()+"</span><br><span style='font-size:14px'>"+String.join(" · ",c.notes())+"</span></center></html>",i==chord.getSelectedIndex());
                Style.name(button,"Grau "+(i+1)+" do campo");button.setToolTipText("Ver "+c.name()+" no braço");
                button.addActionListener(e->{chord.setSelectedIndex(degree);refreshFeature();});grid.add(button);
            }
            JPanel tables=Style.column();tables.add(buildFieldsTable());tables.add(Box.createVerticalStrut(16));tables.add(grid);
            card.add(tables,BorderLayout.CENTER);
            JPanel quality=Style.row(12);quality.add(Style.muted("Empilhamento de terças · clique em um grau para visualizar"));
            JCheckBox fieldSevenths=check("Incluir sétimas",sevenths.isSelected());Style.name(fieldSevenths,"Tétrades no campo");
            fieldSevenths.addActionListener(e->{sevenths.setSelected(fieldSevenths.isSelected());selectionChanged(true);});quality.add(fieldSevenths);
            card.add(quality,BorderLayout.SOUTH);featurePanel.add(card);featurePanel.add(Box.createVerticalStrut(10));
        }else if(circleTab){
            JPanel card=Style.card(new BorderLayout(12,8));card.setAlignmentX(LEFT_ALIGNMENT);
            JPanel title=new JPanel(new BorderLayout(18,0));title.setOpaque(false);
            title.add(sectionTitle("◌","Armadura de Clave"),BorderLayout.CENTER);
            cycleDirection.setPreferredSize(new Dimension(245,42));title.add(cycleDirection,BorderLayout.EAST);card.add(title,BorderLayout.NORTH);
            FifthsPanel cycle=new FifthsPanel((String)root.getSelectedItem(),cycleDirection.getSelectedIndex()==1,key->{root.setSelectedItem(key);});
            card.add(cycle,BorderLayout.CENTER);
            featurePanel.add(card);featurePanel.add(Box.createVerticalStrut(10));
        }
        alignColumns(featurePanel);featurePanel.revalidate();featurePanel.repaint();
    }

    private JPanel buildFieldsTable() {
        // Common written keys are kept in circle order; aliases stay next to each other.
        String[] keys={"C","G","D","A","E","B","F#","Gb","C#","Db","G#","Ab","D#","Eb","A#","Bb","F"};
        String[] columns={"Tom","I","II","III","IV","V","VI","VII"};
        Object[][] values=new Object[keys.length][8];
        Formula scale=(Formula)formula.getSelectedItem();
        for(int row=0;row<keys.length;row++){
            String key=keys[row];values[row][0]=key;
            List<HarmonicChord> chords=Harmony.displayHarmonize(key,scale,sevenths.isSelected(),flats.isSelected());
            for(int col=0;col<7;col++)values[row][col+1]=chords.get(col).name();
        }
        javax.swing.table.DefaultTableModel model=new javax.swing.table.DefaultTableModel(values,columns){@Override public boolean isCellEditable(int row,int col){return false;}};
        JTable table=new JTable(model);Style.name(table,"Tabela de campos harmônicos");
        table.setRowHeight(44);table.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,18));
        table.setSelectionBackground(new Color(213,239,222));table.setSelectionForeground(Style.INK);
        table.setGridColor(new Color(195,190,177));table.setShowGrid(true);table.setIntercellSpacing(new Dimension(1,1));table.setCellSelectionEnabled(true);
        table.getTableHeader().setReorderingAllowed(false);table.getTableHeader().setResizingAllowed(false);
        table.getTableHeader().setPreferredSize(new Dimension(1200,44));
        table.getTableHeader().setDefaultRenderer(new javax.swing.table.DefaultTableCellRenderer(){
            @Override public Component getTableCellRendererComponent(JTable t,Object value,boolean selected,boolean focus,int row,int col){
                super.getTableCellRendererComponent(t,value,selected,focus,row,col);setHorizontalAlignment(CENTER);
                setOpaque(true);setBackground(new Color(56,57,55));setForeground(new Color(255,212,96));setFont(new Font(Font.SANS_SERIF,Font.BOLD,18));setBorder(new EmptyBorder(8,6,8,6));return this;
            }
        });
        table.setDefaultRenderer(Object.class,new javax.swing.table.DefaultTableCellRenderer(){
            @Override public Component getTableCellRendererComponent(JTable t,Object value,boolean selected,boolean focused,int row,int col){
                super.getTableCellRendererComponent(t,value,selected,focused,row,col);setHorizontalAlignment(CENTER);
                setFont(new Font(Font.SANS_SERIF,col==0?Font.BOLD:Font.PLAIN,18));
                if(!selected){setBackground(row%2==0?new Color(248,246,240):new Color(233,230,220));setForeground(Style.INK);}
                if(col==0&&!selected)setBackground(new Color(213,210,199));return this;
            }
        });
        for(int col=0;col<8;col++)table.getColumnModel().getColumn(col).setPreferredWidth(col==0?95:160);
        table.addMouseListener(new java.awt.event.MouseAdapter(){@Override public void mouseClicked(java.awt.event.MouseEvent e){
            int row=table.rowAtPoint(e.getPoint()),col=table.columnAtPoint(e.getPoint());if(row<0)return;
            table.changeSelection(row,Math.max(0,col),false,false);applyFieldCell(table,values);
        }});
        table.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER,0),"Aplicar seleção do campo");
        table.getActionMap().put("Aplicar seleção do campo",new AbstractAction(){@Override public void actionPerformed(java.awt.event.ActionEvent e){applyFieldCell(table,values);}});
        table.setToolTipText("Clique em um acorde ou navegue pelas setas e pressione Enter para estudar. Grafias enarmônicas representam os mesmos sons.");
        int selected=-1;for(int i=0;i<keys.length;i++)if(keys[i].equals(root.getSelectedItem()))selected=i;
        if(selected>=0)table.changeSelection(selected,0,false,false);
        int height=keys.length*table.getRowHeight();
        table.setPreferredSize(new Dimension(1215,height));table.setMinimumSize(new Dimension(850,height));table.setMaximumSize(new Dimension(Integer.MAX_VALUE,height));
        JPanel panel=new JPanel(new BorderLayout());panel.setOpaque(false);Style.name(panel,"Tabela completa sem rolagem interna");
        panel.add(table.getTableHeader(),BorderLayout.NORTH);panel.add(table,BorderLayout.CENTER);
        panel.setPreferredSize(new Dimension(1215,height+46));panel.setMinimumSize(new Dimension(850,height+46));panel.setMaximumSize(new Dimension(Integer.MAX_VALUE,height+46));
        panel.setAlignmentX(LEFT_ALIGNMENT);panel.setBorder(javax.swing.BorderFactory.createLineBorder(new Color(195,190,177)));return panel;
    }

    private void applyFieldCell(JTable table,Object[][] values){
        int row=table.getSelectedRow(),column=table.getSelectedColumn();if(row<0||row>=values.length)return;
        root.setSelectedItem(values[row][0]);if(column>0)chord.setSelectedIndex(column-1);refreshFeature();
    }

    private void updateImprovisation(Study current) {
        advicePanel.removeAll();
        var advice=cleared||harmonyTab||circleTab?java.util.Optional.<ImprovisationAdvice.Advice>empty():ImprovisationAdvice.forSelection(current.root(),current.formula(),flats.isSelected());
        advicePanel.setVisible(advice.isPresent());if(advice.isEmpty())return;
        var lesson=advice.get();JPanel card=Style.card(new BorderLayout(0,14));card.setAlignmentX(LEFT_ALIGNMENT);
        Style.name(card,"Sugestões de improvisação");card.add(sectionTitle("♪","Improvisação e finais de frase"),BorderLayout.NORTH);
        JPanel content=Style.column();content.add(readableParagraph(lesson.context(),16,850));content.add(Box.createVerticalStrut(14));
        JPanel targets=new JPanel(new GridLayout(0,Math.min(3,Math.max(1,lesson.targets().size())),12,12));targets.setOpaque(false);
        for(var target:lesson.targets()){
            JPanel item=Style.card(new BorderLayout(0,10));
            JLabel title=Style.text("Sobre "+target.chord(),20,true);title.setForeground(new Color(15,115,63));item.add(title,BorderLayout.NORTH);
            JPanel body=Style.column();JLabel notes=Style.text(String.join("  ·  ",target.endingNotes()),18,true);body.add(notes);body.add(Box.createVerticalStrut(8));
            body.add(readableParagraph(target.explanation(),15,240));item.add(body,BorderLayout.CENTER);targets.add(item);
        }
        content.add(targets);content.add(Box.createVerticalStrut(15));
        content.add(Style.text("Progressões para experimentar",17,true));content.add(Box.createVerticalStrut(7));
        for(String progression:lesson.progressions())content.add(readableParagraph("• "+progression,16,850));
        content.add(Box.createVerticalStrut(10));content.add(readableParagraph(lesson.phraseTip(),16,850));
        content.add(Box.createVerticalStrut(8));WrappingText caution=readableParagraph(lesson.caution(),14,850);caution.setForeground(Style.MUTED);content.add(caution);
        card.add(content,BorderLayout.CENTER);advicePanel.add(card);advicePanel.revalidate();
    }

    private static WrappingText readableParagraph(String body,int size,int width){return new WrappingText(body,size,width);}

    private static void alignColumns(Container root){
        if(root.getLayout() instanceof BoxLayout box&&box.getAxis()==BoxLayout.Y_AXIS){
            for(Component child:root.getComponents())if(child instanceof JComponent jc)jc.setAlignmentX(LEFT_ALIGNMENT);
        }
        for(Component child:root.getComponents())if(child instanceof Container nested)alignColumns(nested);
    }

    private static String html(String text){return text.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");}

    private static final class GearIcon implements Icon {
        @Override public int getIconWidth(){return 23;}
        @Override public int getIconHeight(){return 23;}
        @Override public void paintIcon(Component c,Graphics graphics,int x,int y){
            Graphics2D g=(Graphics2D)graphics.create();g.translate(x+11.5,y+11.5);
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);g.setColor(Style.ACCENT);
            for(int i=0;i<8;i++){g.fillRoundRect(-2,-11,4,5,1,1);g.rotate(Math.PI/4);}
            g.setStroke(new BasicStroke(2.5f));g.drawOval(-8,-8,16,16);g.setStroke(new BasicStroke(2));g.drawOval(-3,-3,6,6);g.dispose();
        }
    }

    /** Keep the page at viewport width; the neck alone may scroll horizontally. */
    private static final class StudyPage extends JPanel implements Scrollable {
        @Override public Dimension getPreferredScrollableViewportSize(){return getPreferredSize();}
        @Override public int getScrollableUnitIncrement(Rectangle r,int orientation,int direction){return 22;}
        @Override public int getScrollableBlockIncrement(Rectangle r,int orientation,int direction){return Math.max(22,r.height-30);}
        @Override public boolean getScrollableTracksViewportWidth(){return true;}
        @Override public boolean getScrollableTracksViewportHeight(){return false;}
    }
}
