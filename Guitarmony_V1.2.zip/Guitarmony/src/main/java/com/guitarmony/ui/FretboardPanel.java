package com.guitarmony.ui;

import com.guitarmony.fretboard.Cell;
import com.guitarmony.music.Notes;
import com.guitarmony.music.Tuning;
import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.ToolTipManager;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GradientPaint;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Arc2D;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;

/**
 * A vector-drawn guitar neck with clear note-map and realistic maple views.
 * Inlays and vertical frets retain the instrument reference without string lines. Painting is
 * bounded to 150 cells; spelling and layer membership are computed on changes.
 */
public final class FretboardPanel extends JPanel implements javax.swing.Scrollable {
    /** Below this width the viewport scrolls instead of shrinking note labels. */
    public static final int MIN_READABLE_WIDTH = 1450;
    public static final int PREFERRED_HEIGHT = 450;
    public static final int MIN_READABLE_HEIGHT = 390;
    public static final int NOTE_FONT_SIZE = 16;
    private static final Color INK = new Color(0x20252B);
    private static final Color MUTED = new Color(0x73777E);
    private static final Color TONIC = new Color(0x087A46);
    private static final Color TONIC_EDGE = new Color(0x004D2C);
    private static final int[] MARKERS = {3, 5, 7, 9, 12, 15, 17, 19, 21, 24};
    private Tuning tuning = Tuning.standard();
    private List<Layer> layers = List.of();
    private Map<Cell, List<Layer>> memberships = Map.of();
    private Map<Layer, List<String>> spellings = Map.of();
    private boolean darkWood;
    private boolean intervalLabels;
    private boolean flats;
    private boolean showAllNotes = true;
    private Consumer<Cell> cellListener = cell -> {};
    private Cell hover;

    public FretboardPanel() {
        setOpaque(false);
        setBackground(new Color(0xEEECE8));
        setPreferredSize(new Dimension(MIN_READABLE_WIDTH, PREFERRED_HEIGHT));
        setMinimumSize(new Dimension(MIN_READABLE_WIDTH, MIN_READABLE_HEIGHT));
        getAccessibleContext().setAccessibleName("Braço da guitarra: seis cordas, casas zero a vinte e quatro");
        ToolTipManager.sharedInstance().registerComponent(this);
        MouseAdapter mouse = new MouseAdapter() {
            @Override public void mouseMoved(MouseEvent e) {
                Cell next = hit(e.getX(), e.getY());
                if (!Objects.equals(hover, next)) {
                    hover = next;
                    setCursor(next == null ? Cursor.getDefaultCursor() : Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                    repaint();
                }
            }
            @Override public void mouseExited(MouseEvent e) { hover = null; repaint(); }
            @Override public void mouseClicked(MouseEvent e) {
                Cell cell = hit(e.getX(), e.getY());
                if (cell != null) cellListener.accept(cell);
            }
        };
        addMouseListener(mouse);
        addMouseMotionListener(mouse);
    }

    public void setData(Tuning tuning, List<Layer> layers, boolean darkWood,
                        boolean intervalLabels, boolean flats, boolean showAllNotes) {
        this.tuning = Objects.requireNonNull(tuning);
        this.layers = List.copyOf(layers);
        this.darkWood = darkWood;
        this.intervalLabels = intervalLabels;
        this.flats = flats;
        this.showAllNotes = showAllNotes;
        Map<Cell, List<Layer>> cells = new HashMap<>();
        Map<Layer, List<String>> names = new HashMap<>();
        for (Layer layer : layers) {
            names.put(layer, Notes.display(layer.root(), layer.formula(), flats));
            for (Cell cell : layer.cells()) cells.computeIfAbsent(cell, key -> new ArrayList<>()).add(layer);
        }
        Map<Cell, List<Layer>> immutable = new HashMap<>();
        cells.forEach((cell, list) -> immutable.put(cell, List.copyOf(list)));
        memberships = Map.copyOf(immutable);
        spellings = Map.copyOf(names);
        repaint();
    }

    // Fit all twenty-four frets on normal desktop windows; keep scrolling only
    // when there is too little room to retain readable note targets.
    @Override public Dimension getPreferredScrollableViewportSize() { return getPreferredSize(); }
    @Override public int getScrollableUnitIncrement(java.awt.Rectangle visible, int orientation, int direction) { return 45; }
    @Override public int getScrollableBlockIncrement(java.awt.Rectangle visible, int orientation, int direction) { return Math.max(45, visible.width - 45); }
    @Override public boolean getScrollableTracksViewportWidth() {
        return getParent() instanceof javax.swing.JViewport viewport && viewport.getWidth() >= MIN_READABLE_WIDTH;
    }
    @Override public boolean getScrollableTracksViewportHeight() {
        return getParent() instanceof javax.swing.JViewport viewport && viewport.getHeight() >= MIN_READABLE_HEIGHT;
    }

    public void setCellListener(Consumer<Cell> listener) { cellListener = Objects.requireNonNull(listener); }

    /** Export a high-resolution image using the same painter as the live neck. */
    public void exportPng(Path path) throws IOException {
        Objects.requireNonNull(path);
        Path parent = path.toAbsolutePath().getParent();
        if (parent != null) Files.createDirectories(parent);
        BufferedImage image = new BufferedImage(1800, PREFERRED_HEIGHT, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = image.createGraphics();
        try {
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, image.getWidth(), image.getHeight());
            paintNeck(g, image.getWidth(), image.getHeight(), true);
        } finally { g.dispose(); }
        if (!ImageIO.write(image, "png", path.toFile())) throw new IOException("Nenhum gravador PNG disponível.");
    }

    @Override protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g = (Graphics2D) graphics.create();
        try { paintNeck(g, getWidth(), getHeight(), false); }
        finally { g.dispose(); }
    }

    private void paintNeck(Graphics2D g, int width, int height, boolean exporting) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        Geometry geo = new Geometry(width, height);
        Color wood = darkWood ? new Color(0xD7AD70) : new Color(0xEED9B7);
        RoundRectangle2D board = new RoundRectangle2D.Double(geo.left, geo.top, geo.boardWidth, geo.boardHeight, 18, 18);
        g.setColor(new Color(0, 0, 0, 25));
        g.fill(new RoundRectangle2D.Double(geo.left, geo.top + 4, geo.boardWidth, geo.boardHeight, 18, 18));
        g.setPaint(new GradientPaint(0, (float) geo.top, wood.brighter(), 0,
                (float) (geo.top + geo.boardHeight), wood));
        g.fill(board);
        Shape previousClip = g.getClip();
        g.clip(board);
        if (darkWood) {
            // Maple grain is deterministic, subtle, and has no image-loading overhead.
            g.setStroke(new BasicStroke(.8f));
            for (int y = 3; y < geo.boardHeight; y += 5) {
                g.setColor(new Color(107, 62, 22, 12 + y % 11));
                Path2D grain = new Path2D.Double();
                grain.moveTo(geo.left, geo.top + y);
                grain.curveTo(geo.left + geo.boardWidth * .28, geo.top + y + Math.sin(y) * 5,
                        geo.left + geo.boardWidth * .7, geo.top + y - 3, geo.left + geo.boardWidth, geo.top + y + 1);
                g.draw(grain);
            }
            // Pearl markers sit between the two middle strings, as on a real guitar.
            for (int fret : MARKERS) {
                double x = geo.x(fret);
                if (fret == 12 || fret == 24) {
                    pearl(g, x, geo.top + geo.rowHeight * 2, geo.radius * .45);
                    pearl(g, x, geo.top + geo.rowHeight * 4, geo.radius * .45);
                } else pearl(g, x, geo.top + geo.boardHeight * .5, geo.radius * .5);
            }
        }
        g.setColor(new Color(0xE7DFD0));
        g.fillRect((int) geo.left, (int) geo.top, (int) Math.ceil(geo.cellWidth), (int) geo.boardHeight);
        for (int fret = 1; fret <= 24; fret++) {
            double x = geo.left + geo.cellWidth * fret;
            if (fret == 1) {
                // Ivory nut separates the open strings from the first fret.
                g.setColor(new Color(0x948774));
                g.fillRect((int) x - 4, (int) geo.top, 8, (int) geo.boardHeight);
                g.setColor(new Color(0xF7EEDB));
                g.fillRect((int) x - 2, (int) geo.top, 4, (int) geo.boardHeight);
            } else {
                g.setColor(darkWood ? new Color(0x827D70) : new Color(0xC8B896));
                g.setStroke(new BasicStroke(darkWood ? 3f : 1.2f));
                g.drawLine((int) x, (int) geo.top, (int) x, (int) (geo.top + geo.boardHeight));
                if (darkWood) {
                    g.setColor(new Color(0xECE8DE));
                    g.setStroke(new BasicStroke(1f));
                    g.drawLine((int) x - 1, (int) geo.top, (int) x - 1, (int) (geo.top + geo.boardHeight));
                }
            }
        }
        g.setClip(previousClip);
        g.setStroke(new BasicStroke(1));
        g.setColor(new Color(0xC1A885));
        g.draw(board);

        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        for (int fret = 0; fret <= 24; fret++) {
            g.setColor(fret == 0 ? new Color(0xB77800) : MUTED);
            center(g, fret == 0 ? "SOLTA" : String.valueOf(fret), geo.x(fret), geo.top - 16);
        }
        for (int string = 0; string < 6; string++) {
            double y = geo.y(string);
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
            g.setColor(MUTED);
            center(g, (6 - string) + "ª", 22, y + 4);
            for (int fret = 0; fret <= 24; fret++) drawNote(g, geo, new Cell(string, fret));
        }
        double markersY = geo.top + geo.boardHeight + 17;
        g.setColor(new Color(0xA6ACBD));
        for (int fret : MARKERS) {
            double x = geo.x(fret);
            if (fret == 12 || fret == 24) {
                g.fillOval((int) x - 6, (int) markersY - 2, 4, 4);
                g.fillOval((int) x + 2, (int) markersY - 2, 4, 4);
            } else g.fillOval((int) x - 2, (int) markersY - 2, 4, 4);
        }
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        g.setColor(MUTED);
        String caption = "6ª corda grave embaixo · 1ª corda aguda em cima · T = tônica · losango = blue note";
        if (exporting) caption = "GUITARMONY  /  " + caption;
        g.drawString(caption, (int) geo.left, height - 14);
        if (exporting && !layers.isEmpty()) {
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
            String title = layers.size() == 1 ? layers.get(0).label() : layers.size() + " desenhos/camadas · " + layers.get(0).label();
            g.setColor(INK);
            g.drawString(title, (int) geo.left, 17);
        }
    }

    private void drawNote(Graphics2D g, Geometry geo, Cell cell) {
        List<Layer> matches = memberships.getOrDefault(cell, List.of());
        boolean active = !matches.isEmpty();
        if (!showAllNotes && !active) return;
        double x = geo.x(cell.fret());
        double y = geo.y(cell.stringIndex());
        double radius = geo.radius;
        int pitch = tuning.pitchAt(cell.stringIndex(), cell.fret());
        boolean tonic = matches.stream().anyMatch(layer -> pitch == Notes.pitch(layer.root()));
        boolean blue = matches.stream().anyMatch(layer -> isBlue(layer, pitch));
        String text = active ? label(matches.get(0), pitch) : tuning.nameAt(cell.stringIndex(), cell.fret(), flats);
        Color foreground = tonic ? Color.WHITE : INK;
        Color fill = tonic ? TONIC : active ? lighten(matches.get(0).color(), .12) : new Color(0xFFF9EC);
        g.setColor(new Color(0, 0, 0, darkWood ? 22 : 13));
        g.fillOval((int) (x - radius), (int) (y - radius + 2), (int) (radius * 2), (int) (radius * 2));
        g.setColor(fill);
        g.fillOval((int) (x - radius), (int) (y - radius), (int) (radius * 2), (int) (radius * 2));
        g.setColor(tonic ? TONIC_EDGE : active ? darken(matches.get(0).color(), .28) : new Color(0xCFC0A5));
        g.setStroke(new BasicStroke(active ? 1.8f : 1f));
        g.drawOval((int) (x - radius), (int) (y - radius), (int) (radius * 2), (int) (radius * 2));
        if (matches.size() > 1) {
            double diameter = radius * 2 + 6;
            double sweep = 360.0 / matches.size();
            g.setStroke(new BasicStroke(3.3f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_ROUND));
            for (int i = 0; i < matches.size(); i++) {
                g.setColor(darken(matches.get(i).color(), .08));
                g.draw(new Arc2D.Double(x - diameter / 2, y - diameter / 2, diameter, diameter,
                        90 - (i + 1) * sweep + 2, sweep - 4, Arc2D.OPEN));
            }
        }
        if (tonic) {
            g.setColor(new Color(0x68E7A4));
            g.setStroke(new BasicStroke(1.5f));
            double r = radius + 2;
            g.drawOval((int) (x - r), (int) (y - r), (int) (r * 2), (int) (r * 2));
            g.setColor(TONIC_EDGE);
            g.fillOval((int) (x + radius - 8), (int) (y - radius - 3), 13, 13);
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 9));
            g.setColor(Color.WHITE);
            center(g, "T", x + radius - 1.5, y - radius + 7);
        }
        // Stable font sizes make a long neck readable instead of shrinking text
        // to fit a narrow viewport. Scrollable preserves the minimum board width.
        g.setFont(new Font(Font.SANS_SERIF, active ? Font.BOLD : Font.PLAIN,
                text.length() >= 4 ? 14 : NOTE_FONT_SIZE));
        g.setColor(foreground);
        FontMetrics fm = g.getFontMetrics();
        center(g, text, x, y + (fm.getAscent() - fm.getDescent()) / 2.0);
        if (blue) {
            double dx = x + radius - 1, dy = y + radius - 2;
            Path2D diamond = new Path2D.Double();
            diamond.moveTo(dx, dy - 5); diamond.lineTo(dx + 5, dy);
            diamond.lineTo(dx, dy + 5); diamond.lineTo(dx - 5, dy); diamond.closePath();
            g.setColor(new Color(0x397894)); g.fill(diamond);
            g.setColor(Color.WHITE); g.setStroke(new BasicStroke(1)); g.draw(diamond);
        }
        if (cell.equals(hover)) {
            g.setColor(new Color(0xB77800));
            g.setStroke(new BasicStroke(2));
            double r = radius + 6;
            g.drawOval((int) (x - r), (int) (y - r), (int) (r * 2), (int) (r * 2));
        }
    }

    private String label(Layer layer, int pitch) {
        int relative = Math.floorMod(pitch - Notes.pitch(layer.root()), 12);
        int index = layer.formula().intervals().indexOf(relative);
        if (index < 0) return Notes.chromatic(pitch, flats);
        return intervalLabels ? layer.formula().degrees().get(index) : spellings.get(layer).get(index);
    }

    private static boolean isBlue(Layer layer, int pitch) {
        if (!layer.formula().id().startsWith("blues-")) return false;
        int relative = Math.floorMod(pitch - Notes.pitch(layer.root()), 12);
        int blueInterval = switch (layer.formula().id()) {
            case "blues-major" -> 3;
            case "blues-halfdim" -> 7;
            default -> 6;
        };
        return relative == blueInterval;
    }

    @Override public String getToolTipText(MouseEvent e) {
        Cell cell = hit(e.getX(), e.getY());
        if (cell == null) return null;
        int pitch = tuning.pitchAt(cell.stringIndex(), cell.fret());
        StringBuilder html = new StringBuilder("<html><b>")
                .append(escape(tuning.nameAt(cell.stringIndex(), cell.fret(), flats)))
                .append("</b> · ").append(6 - cell.stringIndex()).append("ª corda · ")
                .append(cell.fret() == 0 ? "corda solta" : "casa " + cell.fret());
        for (Layer layer : memberships.getOrDefault(cell, List.of())) {
            int relative = Math.floorMod(pitch - Notes.pitch(layer.root()), 12);
            int index = layer.formula().intervals().indexOf(relative);
            String degree = index < 0 ? Notes.intervalLabel(relative) : layer.formula().degrees().get(index);
            String note = index < 0 ? Notes.chromatic(pitch, flats) : spellings.get(layer).get(index);
            html.append("<br>").append(escape(layer.label())).append(": ")
                    .append(escape(note)).append(" · grau ").append(escape(degree));
            if (isBlue(layer, pitch)) html.append(" · blue note");
        }
        return html.append("</html>").toString();
    }

    private Cell hit(int x, int y) {
        Geometry geo = new Geometry(getWidth(), getHeight());
        int fret = (int) Math.floor((x - geo.left) / geo.cellWidth);
        int row = (int) Math.floor((y - geo.top) / geo.rowHeight);
        if (fret < 0 || fret > 24 || row < 0 || row > 5) return null;
        int string = 5 - row;
        double dx = x - geo.x(fret), dy = y - geo.y(string);
        return dx * dx + dy * dy <= Math.pow(geo.radius + 7, 2) ? new Cell(string, fret) : null;
    }

    private static void pearl(Graphics2D g, double x, double y, double radius) {
        g.setColor(new Color(0xB79A6B));
        g.fillOval((int) (x - radius - 1), (int) (y - radius - 1), (int) (radius * 2 + 2), (int) (radius * 2 + 2));
        g.setColor(new Color(0xEEE8D4));
        g.fillOval((int) (x - radius), (int) (y - radius), (int) (radius * 2), (int) (radius * 2));
    }

    private static Color lighten(Color color, double amount) {
        return new Color((int) (color.getRed() * (1 - amount) + 255 * amount),
                (int) (color.getGreen() * (1 - amount) + 255 * amount),
                (int) (color.getBlue() * (1 - amount) + 255 * amount));
    }

    private static Color darken(Color color, double amount) {
        return new Color((int) (color.getRed() * (1 - amount)),
                (int) (color.getGreen() * (1 - amount)), (int) (color.getBlue() * (1 - amount)));
    }

    private static void center(Graphics2D g, String text, double x, double baseline) {
        g.drawString(text, (float) (x - g.getFontMetrics().stringWidth(text) / 2.0), (float) baseline);
    }

    private static String escape(String value) {
        return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private static final class Geometry {
        final double left = 46;
        final double top = 52;
        final double boardWidth;
        final double boardHeight;
        final double cellWidth;
        final double rowHeight;
        final double radius;
        Geometry(int width, int height) {
            boardWidth = Math.max(MIN_READABLE_WIDTH - left - 18, width - left - 18);
            boardHeight = Math.max(MIN_READABLE_HEIGHT - top - 58, height - top - 58);
            cellWidth = boardWidth / 25.0;
            rowHeight = boardHeight / 6.0;
            radius = Math.min(23.0, Math.min(cellWidth * .37, rowHeight * .41));
        }
        double x(int fret) { return left + cellWidth * (fret + .5); }
        double y(int string) { return top + rowHeight * (5 - string + .5); }
    }
}
