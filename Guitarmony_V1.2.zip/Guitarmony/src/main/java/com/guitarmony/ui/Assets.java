package com.guitarmony.ui;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/** Bundled branding; scaled once, never loaded from the network. */
public final class Assets {
    private static final Map<String,ImageIcon> CACHE=new HashMap<>();
    private Assets() {}
    public static ImageIcon icon(int size){return image("guitarmony.png",size,size);}
    public static ImageIcon logo(int width,int height){return image("logo.png",width,height);}
    private static synchronized ImageIcon image(String name,int width,int height) {
        String key=name+width+"x"+height;
        return CACHE.computeIfAbsent(key,k->{
            try {
                var resource=Assets.class.getResource("/com/guitarmony/assets/"+name);
                BufferedImage original=resource==null?null:ImageIO.read(resource);
                if(original==null)throw new IOException("Brand asset missing: "+name);
                BufferedImage result=new BufferedImage(width,height,BufferedImage.TYPE_INT_ARGB);
                Graphics2D g=result.createGraphics();
                g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BICUBIC);
                double ratio=Math.min((double)width/original.getWidth(),(double)height/original.getHeight());
                int w=(int)Math.round(original.getWidth()*ratio),h=(int)Math.round(original.getHeight()*ratio);
                g.drawImage(original,(width-w)/2,(height-h)/2,w,h,null);g.dispose();return new ImageIcon(result);
            } catch(IOException e){throw new IllegalStateException(e);}
        });
    }
}
