package com.guitarmony.ui;

import com.guitarmony.music.Notes;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.function.Consumer;

/** Readable armature wheel. Fourths reverse the physical order of the fifths wheel. */
final class FifthsPanel extends JPanel {
    private static final String[] KEYS={"C","G","D","A","E","B","F#","Db","Ab","Eb","Bb","F"};
    private static final String[] SIGNATURE={"sem acidentes","1 sustenido","2 sustenidos","3 sustenidos","4 sustenidos","5 sustenidos","6 sustenidos / 6 bemóis","5 bemóis","4 bemóis","3 bemóis","2 bemóis","1 bemol"};
    private final String selected;
    private final boolean fourths;
    FifthsPanel(String selected,Consumer<String> onSelection){this(selected,false,onSelection);}
    FifthsPanel(String selected,boolean fourths,Consumer<String> onSelection) {
        super(new BorderLayout(24,0));setOpaque(false);this.selected=selected;this.fourths=fourths;
        setPreferredSize(new Dimension(1150,480));setMinimumSize(new Dimension(800,460));
        Style.name(this,"Painel de armadura de clave");
        JPanel wheel=new JPanel(){
            private int hovered=-1;
            {
                setOpaque(false);setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                MouseAdapter mouse=new MouseAdapter(){
                    @Override public void mouseMoved(MouseEvent e){int next=keyAt(e.getPoint());if(next!=hovered){hovered=next;repaint();}}
                    @Override public void mouseExited(MouseEvent e){hovered=-1;repaint();}
                    @Override public void mouseClicked(MouseEvent e){int key=keyAt(e.getPoint());if(key>=0)onSelection.accept(keyForSlot(key));}
                };addMouseListener(mouse);addMouseMotionListener(mouse);
                setToolTipText(fourths?"Sentido horário: C → F → Bb. Clique em um tom.":"Sentido horário: C → G → D. Clique em um tom.");
                Style.name(this,fourths?"Ciclo das quartas interativo":"Ciclo das quintas interativo");
            }
            private int keyAt(Point p){
                double cx=getWidth()/2d,cy=getHeight()/2d,r=Math.min(getWidth(),getHeight())*.385;
                for(int i=0;i<12;i++){double a=i*Math.PI/6-Math.PI/2;if(p.distance(cx+Math.cos(a)*r,cy+Math.sin(a)*r)<32)return i;}return -1;
            }
            @Override protected void paintComponent(Graphics graphics){
                super.paintComponent(graphics);Graphics2D g=(Graphics2D)graphics.create();
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                double cx=getWidth()/2d,cy=getHeight()/2d,r=Math.min(getWidth(),getHeight())*.385;
                g.setColor(new Color(202,197,183));g.setStroke(new BasicStroke(3));g.drawOval((int)(cx-r),(int)(cy-r),(int)(2*r),(int)(2*r));
                for(int i=0;i<12;i++){
                    String name=keyForSlot(i);double a=i*Math.PI/6-Math.PI/2;int x=(int)(cx+Math.cos(a)*r),y=(int)(cy+Math.sin(a)*r);
                    boolean active=Notes.pitch(name)==Notes.pitch(FifthsPanel.this.selected);
                    g.setColor(active?new Color(18,133,73):hovered==i?new Color(255,219,121):new Color(247,244,234));g.fillOval(x-30,y-30,60,60);
                    g.setColor(active?new Color(9,88,47):new Color(177,169,145));g.setStroke(new BasicStroke(2));g.drawOval(x-30,y-30,60,60);
                    g.setColor(active?Color.WHITE:Style.INK);g.setFont(new Font(Font.SANS_SERIF,Font.BOLD,22));
                    FontMetrics fm=g.getFontMetrics();g.drawString(name,x-fm.stringWidth(name)/2,y+8);
                    String minor=Notes.chromatic(Notes.pitch(name)+9,name.contains("b"))+"m";
                    int ix=(int)(cx+Math.cos(a)*r*.63),iy=(int)(cy+Math.sin(a)*r*.63);
                    g.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,16));g.setColor(Style.MUTED);g.drawString(minor,ix-g.getFontMetrics().stringWidth(minor)/2,iy+5);
                }
                g.setFont(new Font(Font.SANS_SERIF,Font.BOLD,22));g.setColor(Style.INK);String title=fourths?"QUARTAS":"QUINTAS";
                g.drawString(title,(int)cx-g.getFontMetrics().stringWidth(title)/2,(int)cy-6);
                g.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,15));String direction="→ sentido horário";
                g.setColor(Style.MUTED);g.drawString(direction,(int)cx-g.getFontMetrics().stringWidth(direction)/2,(int)cy+19);g.dispose();
            }
        };
        add(wheel,BorderLayout.CENTER);
        int p=Notes.pitch(selected),index=0;for(int i=0;i<12;i++)if(Notes.pitch(KEYS[i])==p)index=i;
        JPanel details=Style.column();details.setBorder(new EmptyBorder(12,0,0,8));details.setPreferredSize(new Dimension(355,390));
        String detailRoot=switch(selected){case "G#"->"Ab";case "D#"->"Eb";case "A#"->"Bb";default->selected;};
        boolean flatDetails=detailRoot.contains("b");
        String title=detailRoot+" maior"+(detailRoot.equals(selected)?"":" ("+selected+")");
        String signature=switch(selected){case "C#"->"7 sustenidos";case "F#"->"6 sustenidos";case "Gb"->"6 bemóis";default->SIGNATURE[index];};
        JLabel key=Style.text(title,30,true);Style.name(key,"Tom da armadura");key.setForeground(new Color(15,119,65));details.add(key);
        JLabel accidentals=Style.text(signature,16,false);Style.name(accidentals,"Acidentes da armadura");details.add(accidentals);
        if(selected.equals("C#")||selected.equals("Gb")){
            details.add(Box.createVerticalStrut(6));details.add(new WrappingText("Equivalente no círculo: "+KEYS[index]+" maior.",15,340));
        }
        details.add(Box.createVerticalStrut(14));
        details.add(Style.text("V · "+Notes.chromatic(p+7,flatDetails)+" · dominante",18,true));details.add(Box.createVerticalStrut(12));
        details.add(Style.text("IV · "+Notes.chromatic(p+5,flatDetails)+" · subdominante",18,true));details.add(Box.createVerticalStrut(12));
        details.add(Style.text("vi · "+Notes.chromatic(p+9,flatDetails)+"m · relativo menor",18,true));details.add(Box.createVerticalStrut(14));
        String next=KEYS[Math.floorMod(index+(fourths?-1:1),12)];
        details.add(new WrappingText("Próximo no sentido horário: "+next+". O intervalo é de "+(fourths?"quarta justa (5 semitons).":"quinta justa (7 semitons)."),17,340));
        details.add(Box.createVerticalStrut(14));
        details.add(new WrappingText("Vizinhos compartilham seis notas. O anel interno mostra os relativos menores.",16,340));
        for(Component child:details.getComponents())if(child instanceof JComponent jc)jc.setAlignmentX(LEFT_ALIGNMENT);add(details,BorderLayout.EAST);
        JPanel keyboard=Style.row(6);Style.name(keyboard,"Tons do ciclo em ordem");
        for(int slot=0;slot<12;slot++){String keyName=keyForSlot(slot);JButton b=Style.button(keyName,Notes.pitch(keyName)==p);b.setFont(new Font(Font.SANS_SERIF,Font.BOLD,17));b.setBorder(new EmptyBorder(8,12,8,12));b.setToolTipText("Selecionar "+keyName+" maior");b.addActionListener(e->onSelection.accept(keyName));keyboard.add(b);}
        add(keyboard,BorderLayout.SOUTH);
    }
    private String keyForSlot(int slot){return KEYS[Math.floorMod(fourths?-slot:slot,12)];}
}
