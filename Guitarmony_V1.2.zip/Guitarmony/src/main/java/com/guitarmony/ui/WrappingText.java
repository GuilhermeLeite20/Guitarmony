package com.guitarmony.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.font.*;
import java.text.AttributedString;

/** Plain wrapping display text without an editor border or a fixed HTML width. */
final class WrappingText extends JComponent {
    private final String text;
    private final int preferredWidth;
    WrappingText(String text,int size,int preferredWidth){this.text=text;this.preferredWidth=preferredWidth;setFont(new Font(Font.SANS_SERIF,Font.PLAIN,size));setForeground(Style.INK);setOpaque(false);setAlignmentX(LEFT_ALIGNMENT);}
    private int lines(Graphics2D g,float width,boolean paint){
        float y=0;FontRenderContext context=g==null?new FontRenderContext(null,true,true):g.getFontRenderContext();
        for(String paragraph:text.split("\\n",-1)){
            if(paragraph.isEmpty()){y+=getFont().getSize2D()+3;continue;}
            AttributedString attributed=new AttributedString(paragraph);attributed.addAttribute(TextAttribute.FONT,getFont());
            LineBreakMeasurer measure=new LineBreakMeasurer(attributed.getIterator(),context);
            while(measure.getPosition()<paragraph.length()){
                TextLayout line=measure.nextLayout(Math.max(100,width));y+=line.getAscent();if(paint)line.draw(g,0,y);y+=line.getDescent()+line.getLeading()+3;
            }
        }
        return Math.max(getFont().getSize()+6,(int)Math.ceil(y));
    }
    @Override public Dimension getPreferredSize(){int width=getWidth()>0?getWidth():preferredWidth;return new Dimension(preferredWidth,lines(null,width,false));}
    @Override public Dimension getMinimumSize(){return new Dimension(100,getFont().getSize()+6);}
    @Override public Dimension getMaximumSize(){return new Dimension(Integer.MAX_VALUE,getPreferredSize().height);}
    @Override protected void paintComponent(Graphics graphics){Graphics2D g=(Graphics2D)graphics.create();g.setColor(getForeground());g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);lines(g,getWidth(),true);g.dispose();}
}
