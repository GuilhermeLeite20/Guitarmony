package com.guitarmony.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/** Shared warm glass cards and brief, event-driven hover transitions. */
final class Style {
    static final int BODY_FONT_SIZE = 14;
    static final Color BG = new Color(64,65,66);
    static final Color INK = new Color(29,31,34);
    static final Color MUTED = new Color(82,84,87);
    static final Color ACCENT = new Color(239,170,0);
    static final Color LINE = new Color(195,192,185);
    static final Color[] COLORS = {
        new Color(248,193,77), new Color(143,194,235), new Color(149,208,171),
        new Color(237,170,124), new Color(191,168,230), new Color(135,209,199),
        new Color(226,165,192)
    };
    private Style() {}
    static JLabel text(String value,int size,boolean bold) {
        JLabel label = new JLabel(value);
        label.setFont(new Font(Font.SANS_SERIF,bold?Font.BOLD:Font.PLAIN,Math.max(BODY_FONT_SIZE,size)));
        label.setForeground(INK);return label;
    }
    static JPanel row(int gap) {
        JPanel p=new JPanel(new WrapLayout(gap));p.setOpaque(false);return p;
    }
    static JPanel column() {
        JPanel p=new JPanel();p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));p.setOpaque(false);return p;
    }
    static JPanel card(LayoutManager layout) {
        JPanel p = new JPanel(layout) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setPaint(new GradientPaint(0,0,new Color(246,244,239,248),getWidth(),getHeight(),new Color(222,219,214,248)));
                g2.fillRoundRect(0,0,getWidth(),getHeight(),17,17);
                g2.setColor(new Color(255,255,255,95));g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,17,17);
                g2.dispose();
            }
        };
        p.setOpaque(false);p.setBorder(new EmptyBorder(12,16,12,16));return p;
    }
    static JButton button(String title,boolean primary) {
        JButton b=new JButton(title) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                Color fill=primary?ACCENT:getBackground();
                Object amount=getClientProperty("hoverAmount");
                float t=amount instanceof Float?(Float)amount:0f;
                Color end=primary?new Color(255,191,32):new Color(255,244,215);
                g2.setColor(mix(fill,end,t));g2.fillRoundRect(0,0,getWidth(),getHeight(),9,9);
                g2.setColor(primary?new Color(187,131,0):LINE);g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,9,9);
                if(getModel().isPressed()){g2.setColor(new Color(124,80,0,24));g2.fillRoundRect(0,0,getWidth(),getHeight(),9,9);}
                if(hasFocus()){g2.setColor(new Color(150,102,0));g2.drawRoundRect(2,2,getWidth()-5,getHeight()-5,7,7);}
                g2.dispose();super.paintComponent(g);
            }
        };
        b.setFont(new Font(Font.SANS_SERIF,Font.BOLD,BODY_FONT_SIZE));b.setForeground(INK);
        b.setBackground(new Color(246,244,240));b.setOpaque(false);b.setContentAreaFilled(false);
        b.setBorder(new EmptyBorder(8,13,8,13));b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));animate(b);return b;
    }
    static void animate(AbstractButton button) {
        final Timer timer=new Timer(15,null);
        timer.addActionListener(e->{
            float current=button.getClientProperty("hoverAmount") instanceof Float?(Float)button.getClientProperty("hoverAmount"):0f;
            float target=button.getModel().isRollover()&&button.isEnabled()?1f:0f;
            float next=current+(target-current)*.35f;
            if(Math.abs(next-target)<.025f){next=target;timer.stop();}
            button.putClientProperty("hoverAmount",next);button.repaint();
        });
        button.getModel().addChangeListener(e->{if(button.isShowing())timer.start();});
        button.addHierarchyListener(e->{if(!button.isShowing())timer.stop();});
    }
    private static Color mix(Color a,Color b,float t) {
        return new Color(Math.round(a.getRed()+(b.getRed()-a.getRed())*t),Math.round(a.getGreen()+(b.getGreen()-a.getGreen())*t),Math.round(a.getBlue()+(b.getBlue()-a.getBlue())*t));
    }
    static void name(JComponent c,String name){c.setName(name);c.getAccessibleContext().setAccessibleName(name);}
    static JLabel muted(String value){JLabel l=text(value,12,false);l.setForeground(MUTED);return l;}
}
