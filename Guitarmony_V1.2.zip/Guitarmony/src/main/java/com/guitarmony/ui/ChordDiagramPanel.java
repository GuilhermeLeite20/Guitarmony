package com.guitarmony.ui;

import com.guitarmony.music.HarmonicChord;
import com.guitarmony.music.GripFingering;
import com.guitarmony.music.Notes;
import com.guitarmony.music.Tuning;
import com.guitarmony.music.Voicing;
import javax.swing.JPanel;
import java.awt.*;
import java.util.Objects;

/** A conventional chord diagram beside the full neck, for one complete fingering. */
public final class ChordDiagramPanel extends JPanel {
    private HarmonicChord chord;
    private Voicing voicing;
    private Tuning tuning = Tuning.standard();
    private boolean flats;
    private GripFingering.Plan fingering;
    public ChordDiagramPanel() {
        setOpaque(false);
        setPreferredSize(new Dimension(274,340));
        setMinimumSize(new Dimension(250,330));
        setName("Diagrama de acorde");
        getAccessibleContext().setAccessibleName("Diagrama de acorde");
    }
    public void setChord(HarmonicChord chord, Voicing voicing, Tuning tuning, boolean preferFlats) {
        this.chord=chord;this.voicing=voicing;this.tuning=Objects.requireNonNull(tuning);this.flats=preferFlats;
        this.fingering=voicing==null?null:voicing.fingering().orElse(null);
        String description=chord==null||voicing==null?"Escolha uma posição para tocar.":
                chord.name()+". Cordas da sexta para a primeira: "+voicing.label()+". X significa corda abafada; zero significa corda solta. Os números nos círculos indicam dedos: um indicador, dois médio, três anelar, quatro mínimo.";
        setToolTipText(description);getAccessibleContext().setAccessibleDescription(description);repaint();
    }
    @Override protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g=(Graphics2D)graphics.create();
        try {
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g.setColor(new Color(250,248,240));g.fillRoundRect(0,0,getWidth(),getHeight(),14,14);
            g.setColor(Style.LINE);g.drawRoundRect(0,0,getWidth()-1,getHeight()-1,14,14);
            if(chord==null||voicing==null){g.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,14));g.setColor(Style.MUTED);center(g,"Escolha uma posição",getWidth()/2d,getHeight()/2d);return;}
            g.setFont(new Font(Font.SANS_SERIF,Font.BOLD,22));g.setColor(Style.INK);center(g,chord.name(),getWidth()/2d,30);
            g.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,14));g.setColor(Style.MUTED);center(g,"Posição para tocar",getWidth()/2d,52);
            int low=25,high=0;
            for(int fret:voicing.frets())if(fret>0){low=Math.min(low,fret);high=Math.max(high,fret);}
            int start=high<=5?1:low;
            double left=42,right=getWidth()-24,top=98,bottom=getHeight()-70;
            double stringGap=(right-left)/5d,rowHeight=(bottom-top)/5d;
            g.setColor(new Color(175,173,162));g.setStroke(new BasicStroke(1.2f));
            for(int string=0;string<6;string++){int x=(int)Math.round(left+string*stringGap);g.drawLine(x,(int)top,x,(int)bottom);}
            for(int row=0;row<=5;row++){int y=(int)Math.round(top+row*rowHeight);g.drawLine((int)left,y,(int)right,y);}
            if(start==1){g.setColor(new Color(73,72,65));g.fillRect((int)left-1,(int)top-3,(int)(right-left)+2,5);}
            g.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,14));g.setColor(Style.MUTED);center(g,start+"ª",20,top+rowHeight/2+5);
            if(fingering!=null)for(var barre:fingering.barres()) {
                float y=(float)(top+(barre.fret()-start+.5)*rowHeight);
                g.setColor(new Color(224,164,15));
                g.setStroke(new BasicStroke(23,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
                g.drawLine((int)(left+barre.firstString()*stringGap),(int)y,(int)(left+barre.lastString()*stringGap),(int)y);
            }
            for(int string=0;string<6;string++) {
                double x=left+string*stringGap;
                int fret=voicing.frets().get(string);
                boolean root=fret>=0&&tuning.pitchAt(string,fret)==Notes.pitch(chord.root());
                if(fret<0){g.setFont(new Font(Font.SANS_SERIF,Font.BOLD,17));g.setColor(Style.MUTED);center(g,"X",x,83);}
                else if(fret==0){g.setColor(root?new Color(8,122,70):Style.INK);g.setStroke(new BasicStroke(2));g.drawOval((int)x-7,68,14,14);}
                else {
                    double y=top+(fret-start+.5)*rowHeight;
                    g.setColor(root?new Color(8,122,70):Style.ACCENT);g.fillOval((int)x-13,(int)y-13,26,26);
                    g.setColor(root?new Color(0,77,44):new Color(160,111,0));g.setStroke(new BasicStroke(1));g.drawOval((int)x-13,(int)y-13,26,26);
                    g.setColor(root?Color.WHITE:Style.INK);g.setFont(new Font(Font.SANS_SERIF,Font.BOLD,13));center(g,Integer.toString(fingering==null?fret:fingering.fingers().get(string)),x,y+5);
                }
                g.setFont(new Font(Font.SANS_SERIF,Font.BOLD,13));g.setColor(Style.MUTED);center(g,(6-string)+"ª",x,bottom+23);
                String note=fret<0?"—":Notes.chromatic(tuning.pitchAt(string,fret),flats||voicing.notes().get(string).contains("b"));
                g.setColor(root?new Color(8,122,70):Style.INK);g.setFont(new Font(Font.SANS_SERIF,root?Font.BOLD:Font.PLAIN,14));center(g,note,x,bottom+43);
            }
            g.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,12));g.setColor(Style.MUTED);center(g,fingering==null?"X abafar   ○ solta   números = casas":"X abafar   ○ solta   1–4 = dedos",getWidth()/2d,getHeight()-10);
        } finally {g.dispose();}
    }
    private static void center(Graphics2D g,String value,double x,double y){g.drawString(value,(float)(x-g.getFontMetrics().stringWidth(value)/2d),(float)y);}
}
