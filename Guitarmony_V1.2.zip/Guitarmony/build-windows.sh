#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
# Install a MinGW-w64 cross compiler or provide its extracted root as this variable.
if [[ -n "${GUITARMONY_MINGW_ROOT:-}" ]]; then
  export PATH="$GUITARMONY_MINGW_ROOT/usr/bin:$PATH"
fi
compiler=x86_64-w64-mingw32-gcc
resource_compiler=x86_64-w64-mingw32-windres
if ! command -v "$compiler" >/dev/null; then compiler=x86_64-w64-mingw32-gcc-posix; fi
if ! command -v "$compiler" >/dev/null || ! command -v "$resource_compiler" >/dev/null; then
  printf '%s\n' 'Instale gcc-mingw-w64-x86-64 e binutils-mingw-w64-x86-64 para compilar o lançador.' >&2
  exit 1
fi
mkdir -p build/windows
(cd windows && "$resource_compiler" --preprocessor="$compiler" --preprocessor-arg=-E --preprocessor-arg=-xc --preprocessor-arg=-DRC_INVOKED --codepage=65001 launcher.rc -O coff -o ../build/windows/launcher.res)
"$compiler" -std=c11 -Wall -Wextra -O2 -s -mwindows -municode -static \
  -Wl,--dynamicbase,--nxcompat,--high-entropy-va \
  windows/launcher.c build/windows/launcher.res -o Guitarmony.exe -luser32
printf '%s\n' 'Criado Guitarmony.exe (Windows x64, subsistema gráfico, sem console).'
