# Guitarmony 2

Estudo visual de guitarra: modos, pentatônicas, pentablues, arpejos, escalas,
acordes, campos harmônicos e ciclo das quintas. Seis cordas, 24 casas e afinações
personalizadas. Funciona sem conexão e não precisa de cadastro.

## Abrir no Windows

1. **Extraia o ZIP inteiro** para uma pasta do computador.
2. Abra **Guitarmony.exe** com dois cliques.

O aplicativo abre sua janela diretamente, sem terminal. O Java portátil já está
incluído: **não é necessário instalar Java**. Mantenha a pasta `dist` ao lado do
executável. Pacote para Windows 10/11 de 64 bits (x64).

`run.vbs` e `run.bat` são atalhos alternativos para o mesmo executável.
Os scripts `build` e `test` são apenas para desenvolvimento.

## Área de estudo

- Selecione uma matéria nas abas superiores, a **tônica**, a **fórmula** e a
  **visualização**. Toda alteração atualiza o braço imediatamente.
- **Braço inteiro** localiza todas as ocorrências; **Um desenho** mostra uma
  posição; **Sequência** conecta desenhos. As tônicas ficam sempre em verde.
- **Sobrepor seleção** fixa o estudo para comparar com outro. **Limpar**, ou
  `Ctrl+L`, remove marcações e progressões.
- Passe o mouse e clique em notas para inspecionar corda, casa, nota e intervalo.
- Leia os quatro blocos **Entenda o que está vendo** para conhecer a estrutura,
  interpretar o braço e praticar cada matéria.

## Configurações

A engrenagem abre uma janela central com:

- Afinação padrão e alternativas, transposição **−/+ 1 tom** (dois semitons) e
  ajuste individual de cada corda.
- Preferência por bemóis e alternância entre braço simplificado e **Escala
  realista**, com madeira, cordas, pestana, trastes e marcações.
- **Corda de partida**: comece um desenho na 6ª Mi, 5ª Lá, 4ª Ré, 3ª Sol,
  2ª Si ou 1ª Mi. As cordas mais graves ficam livres nesse desenho. Essa
  preferência vale para Um desenho e Sequência; Braço inteiro permanece completo.

## Acordes, campos e quintas

**Acordes** reúne seleção de graus, tríades/tétrades, mapa de notas, formas
**Voicing tocável** e progressões. O mapa mostra locais alternativos das notas;
não é um acorde para tocar todas as bolinhas simultaneamente. Voicings mostram
uma posição por corda e X para cordas abafadas. As sugestões calculadas respeitam
uma abertura limitada, mas confira a ergonomia da sua mão.

**Campos** separa a tabela harmônica da construção de acordes. Escolha maior,
menor natural, menor harmônica ou maior harmônica; alterne tríades e tétrades.
A tabela tem as 12 tonalidades. Clique numa cifra ou num cartão de grau para
visualizar aquele acorde no braço.

**Ciclo das quintas** mostra 12 tons maiores, suas relativas menores e armaduras.
Clique num tom para estudar sua escala. No sentido horário, avance uma quinta;
no anti-horário, uma quarta. Dominante e subdominante aparecem ao lado.

A interface usa nomes enarmônicos familiares: por exemplo, F no lugar de E#.
A altura sonora e o grau continuam corretos. A lógica interna preserva a grafia
diatônica para análise e testes; a tela não exibe acidentes pouco usuais ou duplos.

## Desenvolver no IntelliJ ou em outro sistema

Abra `pom.xml` com um **JDK completo 17 ou superior**. Não use apenas um JRE para
compilar. A aplicação é Java/Swing e não possui dependências externas em runtime.

```sh
# Linux/macOS (JDK 17+ no PATH)
bash build.sh
bash test.sh
bash run.sh
```

```bat
rem Windows (JDK 17+ no PATH)
build.bat
test.bat
```

O build atualiza `dist/Guitarmony.jar` incluindo imagens e ícones. Para Linux e
macOS, execute `java -jar dist/Guitarmony.jar` numa sessão gráfica com Java 17+.
O executável e o runtime incluídos são específicos de Windows x64.

Com Maven instalado, `mvn test` executa as mesmas suítes headless e `mvn package`
gera o JAR. Os scripts diretos não precisam do Maven nem de downloads.

As suítes verificam teoria em todas as tonalidades, equivalência enarmônica,
campos maiores/menores, voicings, posições e sequências por corda, cores das
tônicas, interação real dos controles Swing, tabela harmônica e navegação.
Para validar janelas modais e capturas numa sessão gráfica, execute também
`com.guitarmony.DesktopIntegrationChecks` com `build/classes` e
`build/test-classes` no classpath (separador `;` no Windows, `:` no Linux/macOS).

O launcher Windows é nativo e usa `javaw.exe` sem shell. Código, procedimento de
compilação e procedência do Java portátil estão em `windows/`. O funcionamento
Swing foi validado no Linux com display virtual; o executável Windows foi
inspecionado como PE x64 gráfico com ícone. Não foi executado em Windows nesta
máquina de desenvolvimento.
