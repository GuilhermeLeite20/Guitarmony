package com.guitarmony.ui;

import com.guitarmony.music.Notes;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.util.function.Consumer;

/** Interactive twelve-key wheel. Clockwise is seven semitones; counterclockwise is five. */
final class FifthsPanel extends JPanel {
    private static final String[] KEYS={"C","G","D","A","E","B","F#","Db","Ab","Eb","Bb","F"};
    private static final String[] SIGNATURE={"sem acidentes","1 sustenido","2 sustenidos","3 sustenidos","4 sustenidos","5 sustenidos","6 sustenidos / 6 bemóis","5 bemóis","4 bemóis","3 bemóis","2 bemóis","1 bemol"};
    private final String selected;
    FifthsPanel(String selected,Consumer<String> onSelection) {
        super(new BorderLayout(18,0));setOpaque(false);this.selected=selected;
        setPreferredSize(new Dimension(850,280));
        JPanel wheel=new JPanel(){
            private int hovered=-1;
            {
                setOpaque(false);setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                MouseAdapter mouse=new MouseAdapter(){
                    @Override public void mouseMoved(MouseEvent e){int next=keyAt(e.getPoint());if(next!=hovered){hovered=next;repaint();}}
                    @Override public void mouseExited(MouseEvent e){hovered=-1;repaint();}
                    @Override public void mouseClicked(MouseEvent e){int key=keyAt(e.getPoint());if(key>=0)onSelection.accept(KEYS[key]);}
                };addMouseListener(mouse);addMouseMotionListener(mouse);
                setToolTipText("Clique em um tom. Horário: quintas; anti-horário: quartas.");
                getAccessibleContext().setAccessibleName("Ciclo das quintas interativo");
            }
            private int keyAt(Point p){
                double cx=getWidth()/2d,cy=getHeight()/2d,r=Math.min(getWidth(),getHeight())*.365;
                for(int i=0;i<12;i++){double a=i*Math.PI/6-Math.PI/2;double x=cx+Math.cos(a)*r,y=cy+Math.sin(a)*r;
                    if(p.distance(x,y)<23)return i;}
                return -1;
            }
            @Override protected void paintComponent(Graphics graphics){
                super.paintComponent(graphics);Graphics2D g=(Graphics2D)graphics.create();
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                double cx=getWidth()/2d,cy=getHeight()/2d,r=Math.min(getWidth(),getHeight())*.365;
                g.setColor(new Color(205,201,190));g.setStroke(new BasicStroke(2));g.drawOval((int)(cx-r),(int)(cy-r),(int)(2*r),(int)(2*r));
                for(int i=0;i<12;i++){
                    double a=i*Math.PI/6-Math.PI/2;int x=(int)(cx+Math.cos(a)*r),y=(int)(cy+Math.sin(a)*r);
                    boolean active=Notes.pitch(KEYS[i])==Notes.pitch(FifthsPanel.this.selected);
                    g.setColor(active?new Color(19,132,74):hovered==i?new Color(255,220,127):new Color(245,242,231));
                    g.fillOval(x-22,y-22,44,44);g.setColor(active?new Color(11,94,52):new Color(185,177,156));g.drawOval(x-22,y-22,44,44);
                    g.setColor(active?Color.WHITE:Style.INK);g.setFont(new Font(Font.SANS_SERIF,Font.BOLD,15));
                    FontMetrics fm=g.getFontMetrics();g.drawString(KEYS[i],x-fm.stringWidth(KEYS[i])/2,y+5);
                    String minor=Notes.chromatic(Notes.pitch(KEYS[i])+9,KEYS[i].contains("b"))+"m";
                    int ix=(int)(cx+Math.cos(a)*r*.58),iy=(int)(cy+Math.sin(a)*r*.58);
                    g.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,11));g.setColor(Style.MUTED);g.drawString(minor,ix-g.getFontMetrics().stringWidth(minor)/2,iy+4);
                }
                g.setFont(new Font(Font.SANS_SERIF,Font.BOLD,17));g.setColor(Style.INK);String title="QUINTAS";g.drawString(title,(int)cx-g.getFontMetrics().stringWidth(title)/2,(int)cy-5);
                g.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,11));g.setColor(Style.MUTED);g.drawString("→ sentido horário",(int)cx-48,(int)cy+15);g.dispose();
            }
        };
        add(wheel,BorderLayout.CENTER);
        int p=Notes.pitch(selected),index=0;for(int i=0;i<12;i++)if(Notes.pitch(KEYS[i])==p)index=i;
        JPanel details=Style.column();details.setBorder(new EmptyBorder(14,0,0,8));details.setPreferredSize(new Dimension(300,245));
        JLabel key=Style.text(selected+" maior",24,true);key.setForeground(new Color(18,130,73));details.add(key);
        details.add(Style.muted(SIGNATURE[index]));details.add(Box.createVerticalStrut(14));
        details.add(Style.text("V  ·  "+KEYS[(index+1)%12]+"  ·  dominante",14,true));details.add(Box.createVerticalStrut(8));
        details.add(Style.text("IV  ·  "+KEYS[(index+11)%12]+"  ·  subdominante",14,true));details.add(Box.createVerticalStrut(8));
        details.add(Style.text("vi  ·  "+Notes.chromatic(p+9,selected.contains("b"))+"m  ·  relativo menor",14,true));
        JLabel hint=new JLabel("<html><div style='width:205px'>Vizinhos compartilham seis notas. O anel interno mostra os relativos menores.</div></html>");
        hint.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,12));hint.setForeground(Style.MUTED);
        details.add(Box.createVerticalStrut(10));details.add(hint);for(Component child:details.getComponents())if(child instanceof JComponent jc)jc.setAlignmentX(LEFT_ALIGNMENT);add(details,BorderLayout.EAST);
        JPanel keyboard=Style.row(4);
        for(String keyName:KEYS){JButton b=Style.button(keyName,Notes.pitch(keyName)==p);b.setBorder(new EmptyBorder(4,9,4,9));b.setToolTipText("Selecionar "+keyName+" maior");b.addActionListener(e->onSelection.accept(keyName));keyboard.add(b);}
        add(keyboard,BorderLayout.SOUTH);
    }
}
