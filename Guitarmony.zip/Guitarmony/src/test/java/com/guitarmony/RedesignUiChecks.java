package com.guitarmony;

import com.guitarmony.fretboard.Cell;
import com.guitarmony.fretboard.ViewMode;
import com.guitarmony.music.*;
import com.guitarmony.ui.Layer;
import com.guitarmony.ui.WorkspacePanel;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.lang.reflect.Field;
import java.nio.file.*;
import java.util.*;
import java.util.List;

/** Covers the redesigned navigation, settings, selected-string construction and tables. */
public final class RedesignUiChecks {
    private static int assertions;
    public static void main(String[] args) throws Exception {
        final Throwable[] error={null};
        SwingUtilities.invokeAndWait(()->{
            try {
                GuitarmonyApp.installLookAndFeel();WorkspacePanel ui=new WorkspacePanel();
                check(find(ui,"Configurações") instanceof JButton,"Settings gear exists");
                check(!hasText(ui,"Escala escura"),"Removed dark scale label");
                check(!hasText(ui,"Exportar PNG"),"Removed export control");
                check(!hasText(ui,"REGIÃO INICIAL / DESENHO"),"Removed region selector");
                check(!hasText(ui,"Como estudar"),"Help label replaced");
                click(ui,"Configurações");
                JComboBox<String> start=combo(ui,"Corda de partida");
                JComboBox<ViewMode> view=combo(ui,"Visualização");
                JComboBox<String> root=combo(ui,"Tônica");
                root.setSelectedItem("C");view.setSelectedItem(ViewMode.ONE_SHAPE);start.setSelectedIndex(1);
                List<Layer> layers=layers(ui);check(!layers.isEmpty(),"Starting-string selection creates a pattern");
                check(layers.get(0).cells().stream().allMatch(c->c.stringIndex()>=1),"A-string pattern excludes bass E");
                check(layers.get(0).cells().stream().anyMatch(c->c.stringIndex()==1),"A-string pattern starts on A string");
                start.setSelectedIndex(5);check(layers(ui).get(0).cells().stream().allMatch(c->c.stringIndex()==5),"High E start remains on high E");
                start.setSelectedIndex(0);view.setSelectedItem(ViewMode.ALL_NOTES);
                click(ui,"Aba Campos");
                JComboBox<Formula> formula=combo(ui,"Fórmula");
                Set<String> scaleIds=new HashSet<>();for(int i=0;i<formula.getItemCount();i++)scaleIds.add(formula.getItemAt(i).id());
                check(scaleIds.containsAll(Set.of("major","natural-minor","harmonic-minor","harmonic-major")),"Fields offer four requested scale families");
                formula.setSelectedItem(Catalog.byId("harmonic-minor"));root.setSelectedItem("A");
                JTable table=(JTable)find(ui,"Tabela de campos harmônicos");
                check(table.getRowCount()==12&&table.getColumnCount()==8,"Fields table includes all twelve keys and seven degrees");
                check("E7".equals(table.getValueAt(9,5)),"A harmonic minor dominant is E7");
                paint(ui,1440,950,Path.of("build/redesign-fields.png"));
                table.setSize(900,table.getRowHeight()*12);int row=0,col=4;
                Rectangle cell=table.getCellRect(row,col,true);
                MouseEvent click=new MouseEvent(table,MouseEvent.MOUSE_CLICKED,System.currentTimeMillis(),0,cell.x+3,cell.y+3,1,false);
                for(var listener:table.getMouseListeners())listener.mouseClicked(click);
                check(root.getSelectedItem().equals("C"),"Clicking field table changes tonic");
                JComboBox<HarmonicChord> chord=combo(ui,"Acorde do campo");check(chord.getSelectedIndex()==3,"Clicking table chooses corresponding chord");
                click(ui,"Aba Ciclo das quintas");
                check(find(ui,"Ciclo das quintas interativo")!=null,"Interactive cycle is accessible");
                clickText(ui,"G");check(root.getSelectedItem().equals("G"),"Cycle key selects new study root");
                check(layers(ui).get(0).formula().id().equals("major"),"Cycle displays scale, not isolated chord");
                paint(ui,1440,950,Path.of("build/redesign-cycle.png"));
                click(ui,"Aba Acordes");check(((JPanel)state(ui,"harmonyControls")).isVisible(),"Chord tab owns its controls");
                click(ui,"Aba Campos");check(!((JPanel)state(ui,"harmonyControls")).isVisible(),"Field tab avoids chord progression clutter");
                click(ui,"Aba "+Family.MODES);root.setSelectedItem("F");
                paint(ui,1440,950,Path.of("build/redesign-1440.png"));
                paint(ui,1100,720,Path.of("build/redesign-1100.png"));
                JPanel settings=(JPanel)state(ui,"settingsPanel");settings.setVisible(true);paint(settings,630,360,Path.of("build/redesign-settings.png"));settings.setVisible(false);
            }catch(Throwable ex){error[0]=ex;}
        });
        if(error[0]!=null)throw new AssertionError("Redesign failed",error[0]);
        System.out.println("Redesign: "+assertions+" checks passed; screenshots 1440×950 / 1100×720.");
    }
    private static void paint(JComponent ui,int w,int h,Path path)throws Exception {
        ui.setSize(w,h);layout(ui);
        if(ui instanceof WorkspacePanel workspace&&!((JPanel)state(workspace,"featurePanel")).isVisible()){
            JComponent selection=find(workspace,"Seleção de estudo"),neck=find(workspace,"Cartão do braço");
            int gap=neck.getY()-selection.getY()-selection.getHeight();
            check(gap>=0&&gap<=24,"Standard tab has no stale feature-panel gap after resize: "+gap);
        }
        BufferedImage image=new BufferedImage(w,h,BufferedImage.TYPE_INT_RGB);
        Graphics2D graphics=image.createGraphics();ui.printAll(graphics);graphics.dispose();Files.createDirectories(path.getParent());ImageIO.write(image,"png",path.toFile());
        check(Files.size(path)>10_000,"Rendered usable UI screenshot");
        if(ui instanceof WorkspacePanel) {
            var board=(com.guitarmony.ui.FretboardPanel)state(ui,"board");
            check(board.getWidth()==board.getParent().getWidth(),"All twenty-four frets fit the available desktop width");
        }
    }
    private static void layout(Container c){c.doLayout();for(Component child:c.getComponents())if(child instanceof Container nested)layout(nested);}
    private static JComponent find(Container root,String name){
        if(root instanceof JComponent jc&&(name.equals(jc.getName())||(jc.getAccessibleContext()!=null&&name.equals(jc.getAccessibleContext().getAccessibleName()))))return jc;
        for(Component c:root.getComponents())if(c instanceof Container nested){JComponent found=find(nested,name);if(found!=null)return found;}return null;
    }
    private static boolean hasText(Container root,String text){for(Component c:root.getComponents()){
        if(c instanceof AbstractButton b&&text.equals(b.getText()))return true;
        if(c instanceof JLabel l&&text.equals(l.getText()))return true;
        if(c instanceof Container nested&&hasText(nested,text))return true;
    }return false;}
    @SuppressWarnings("unchecked") private static <T> JComboBox<T> combo(Container root,String name){JComponent value=find(root,name);if(value==null)throw new AssertionError("Missing "+name);return (JComboBox<T>)value;}
    private static void click(Container root,String name){JComponent c=find(root,name);if(!(c instanceof AbstractButton b))throw new AssertionError("Missing button "+name);b.doClick(0);}
    private static void clickText(Container root,String text){for(Component c:root.getComponents()){
        if(c instanceof AbstractButton b&&text.equals(b.getText())){b.doClick(0);return;}
        if(c instanceof Container nested&&hasText(nested,text)){clickText(nested,text);return;}
    }throw new AssertionError("Missing text button "+text);}
    private static Object state(Object o,String name){try{Field f=o.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(o);}catch(Exception e){throw new AssertionError(e);}}
    @SuppressWarnings("unchecked") private static List<Layer> layers(WorkspacePanel ui){return (List<Layer>)state(ui,"currentLayers");}
    private static void check(boolean condition,String message){assertions++;if(!condition)throw new AssertionError(message);}
}
