package com.guitarmony;

import com.guitarmony.music.Tuning;
import com.guitarmony.ui.WorkspacePanel;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.lang.reflect.Field;
import java.nio.file.*;

/** Native-window validation, including the modal settings event loop. Run under a display server. */
public final class DesktopIntegrationChecks {
    private static int assertions;
    private static Throwable failure;
    public static void main(String[] args)throws Exception {
        if(GraphicsEnvironment.isHeadless())throw new IllegalStateException("This check requires a real display");
        SwingUtilities.invokeAndWait(()->{
            JFrame frame=null;
            try {
                GuitarmonyApp.installLookAndFeel();WorkspacePanel ui=new WorkspacePanel();
                frame=new JFrame("Guitarmony · interface");frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
                frame.setContentPane(ui);frame.setSize(1440,950);frame.setLocation(50,20);frame.setVisible(true);frame.validate();
                JFrame owner=frame;
                write(frame,Path.of("docs/interface-modos.png"));
                Timer inspect=new Timer(300,event->{
                    try {
                        JDialog dialog=(JDialog)state(ui,"settingsDialog");
                        check(dialog.isShowing(),"Settings dialog opens");check(dialog.isModal(),"Settings are modal");
                        Point a=owner.getLocationOnScreen(),b=dialog.getLocationOnScreen();
                        check(Math.abs((a.x+owner.getWidth()/2)-(b.x+dialog.getWidth()/2))<5,"Dialog centered horizontally");
                        check(Math.abs((a.y+owner.getHeight()/2)-(b.y+dialog.getHeight()/2))<5,"Dialog centered vertically");
                        int before=((Tuning)state(ui,"tuning")).midiAt(0,0);
                        ((AbstractButton)find(dialog,"Subir afinação um tom")).doClick(0);
                        check(((Tuning)state(ui,"tuning")).midiAt(0,0)==before+2,"Dialog tuning button updates the study");
                        @SuppressWarnings("unchecked") JComboBox<String> string=(JComboBox<String>)find(dialog,"Corda de partida");string.setSelectedIndex(1);
                        write(dialog,Path.of("docs/interface-configuracoes.png"));
                        dialog.setVisible(false);
                    }catch(Throwable ex){failure=ex;((JDialog)state(ui,"settingsDialog")).setVisible(false);}
                });inspect.setRepeats(false);inspect.start();
                ((AbstractButton)find(ui,"Configurações")).doClick(0);
                if(failure!=null)throw new AssertionError(failure);
                Timer reopen=new Timer(200,event->{
                    try {
                        JDialog dialog=(JDialog)state(ui,"settingsDialog");
                        @SuppressWarnings("unchecked") JComboBox<String> string=(JComboBox<String>)find(dialog,"Corda de partida");
                        check(dialog.isShowing(),"Dialog reopens");check(string.getSelectedIndex()==1,"Settings persist when reopening");
                        dialog.setVisible(false);
                    }catch(Throwable ex){failure=ex;((JDialog)state(ui,"settingsDialog")).setVisible(false);}
                });reopen.setRepeats(false);reopen.start();((AbstractButton)find(ui,"Configurações")).doClick(0);
                if(failure!=null)throw new AssertionError(failure);
                ((AbstractButton)find(ui,"Aba Campos")).doClick(0);frame.validate();write(frame,Path.of("docs/interface-campos.png"));
                ((AbstractButton)find(ui,"Aba Ciclo das quintas")).doClick(0);frame.validate();write(frame,Path.of("docs/interface-ciclo.png"));
            }catch(Throwable ex){failure=ex;}
            finally{if(frame!=null)frame.dispose();for(Window w:Window.getWindows())w.dispose();}
        });
        if(failure!=null)throw new AssertionError("Native desktop integration failed",failure);
        System.out.println("Desktop: "+assertions+" checks passed; native dialog and screenshots validated.");
    }
    private static Object state(Object o,String name){try{Field f=o.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(o);}catch(Exception e){throw new AssertionError(e);}}
    private static JComponent find(Container root,String name){
        if(root instanceof JComponent jc&&name.equals(jc.getName()))return jc;
        for(Component child:root.getComponents())if(child instanceof Container nested){JComponent found=find(nested,name);if(found!=null)return found;}return null;
    }
    private static void write(Component component,Path path)throws Exception{
        BufferedImage image=new BufferedImage(component.getWidth(),component.getHeight(),BufferedImage.TYPE_INT_RGB);Graphics2D g=image.createGraphics();component.printAll(g);g.dispose();
        Files.createDirectories(path.getParent());ImageIO.write(image,"png",path.toFile());check(Files.size(path)>10000,"Native screenshot generated");
    }
    private static void check(boolean value,String description){assertions++;if(!value)throw new AssertionError(description);}
}
