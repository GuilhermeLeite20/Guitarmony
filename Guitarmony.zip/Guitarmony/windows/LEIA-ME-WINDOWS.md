# Executável Windows portátil

1. Extraia **todo o ZIP** para uma pasta local.
2. Abra **Guitarmony.exe** na raiz. Você pode criar um atalho para esse arquivo.
3. Mantenha `dist/Guitarmony.jar` e `dist/runtime` junto do executável.

O lançador usa o subsistema gráfico do Windows e inicia `javaw.exe` diretamente,
sem `cmd.exe`, PowerShell ou janela de terminal. `run.vbs` também abre sem console;
`run.bat` é mantido apenas por compatibilidade. Use o `.exe` no dia a dia.

Ao encontrar a janela Java, o lançador solicita ao Windows uma barra de título
cinza-escura por meio do DWM. A solicitação é opcional e limitada aos primeiros
10 segundos da inicialização. Versões compatíveis do Windows 10 usam modo escuro;
no Windows 11, uma cor cinza-escura também é solicitada. Se a API ou algum atributo
não estiver disponível, a barra padrão do sistema é preservada. Os controles
nativos de mover, redimensionar, minimizar, maximizar e fechar continuam ativos.

Compatível com Windows 10/11 de 64 bits. O Java portátil está incluído; não é
necessário instalar Java ou acessar a internet para usar o aplicativo. Não é um
instalador: mover a pasta completa move o aplicativo, e excluir a pasta o remove.

## Reproduzir o pacote

- Compile o JAR com `bash build.sh` (JDK 17+).
- Em Linux, instale o compilador cruzado MinGW-w64 (`gcc-mingw-w64-x86-64` e
  `binutils-mingw-w64-x86-64`) e rode `bash build-windows.sh`.
- Se necessário, obtenha novamente o runtime com `python3 windows/fetch-runtime.py`.
  Esse script preserva a validação TLS e verifica o SHA-256 fixado; não sobrescreve
  um runtime já existente. O runtime é Eclipse Temurin OpenJDK JRE 21.0.13+9,
  distribuído com suas licenças e avisos originais em `dist/runtime/legal`.

Origem oficial do runtime:
https://github.com/adoptium/temurin21-binaries/releases/tag/jdk-21.0.13%2B9

SHA-256 do ZIP oficial:
`2332c0b4cff6bed722da3567c91d5e47568bcba863fa4945d0a8d6fc76158628`

O lançador é compilado do código aberto `windows/launcher.c`. Não possui assinatura
Authenticode; o Windows pode mostrar uma confirmação de editor desconhecido.

## Validação desta entrega

O JAR e a interface são testados no ambiente Linux de desenvolvimento. O executável
Windows é compilado e inspecionado como PE x64 de subsistema gráfico, com ícone e
metadados. Esta máquina não executa Windows; portanto, abertura real, atalhos,
SmartScreen e a renderização nativa no Windows precisam de verificação nesse sistema.
